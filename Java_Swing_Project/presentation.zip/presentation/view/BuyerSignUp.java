package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.border.LineBorder;

import presentation.model.Buyer;
import presentation.model.BuyerDBA;
import presentation.model.Manager;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.DropMode;
import javax.swing.JTextPane;
import javax.swing.JFormattedTextField;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BuyerSignUp extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JTextField tfName;
	private JTextField tfBirth;
	private JTextField tfGender;
	private JCheckBox cbDesktop;
	private JCheckBox cbLaptop;
	private JCheckBox cbSmartPhone;
	private JCheckBox cbPeripheralDevice;
	private JCheckBox cbEtc;
	private JLabel lblNewLabel_5;
	private JTextField tfEmail;
	private JLabel label;
	private JLabel label_1;
	private JTextField tfId;
	private JLabel label_2;
	private JPasswordField pf;
	private JPasswordField pfConfirm;
	private JButton btnSignUp;
	private JTextArea ta;
	private BuyerDBA byrdba=new BuyerDBA();
	private Buyer byr;
	private JLabel label_3;
	private JTextField tfTel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					BuyerSignUp frame = new BuyerSignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuyerSignUp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 650);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getLblNewLabel_2());
		contentPane.add(getLblNewLabel_3());
		contentPane.add(getLblNewLabel_4());
		contentPane.add(getTfName());
		contentPane.add(getTfBirth());
		contentPane.add(getTfGender());
		contentPane.add(getCbDesktop());
		contentPane.add(getCbLaptop());
		contentPane.add(getCbSmartPhone());
		contentPane.add(getCbPeripheralDevice());
		contentPane.add(getCbEtc());
		contentPane.add(getLblNewLabel_5());
		contentPane.add(getTfEmail());
		contentPane.add(getLabel());
		contentPane.add(getLabel_1());
		contentPane.add(getTfId());
		contentPane.add(getLabel_2());
		contentPane.add(getPf());
		contentPane.add(getPfConfirm());
		contentPane.add(getBtnSignUp());
		contentPane.add(getTa());
		contentPane.add(getLabel_3());
		contentPane.add(getTfTel());
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("이름");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(22, 135, 57, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("생일");
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1.setBounds(22, 170, 57, 15);
		}
		return lblNewLabel_1;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("성별");
			lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_2.setBounds(22, 205, 57, 15);
		}
		return lblNewLabel_2;
	}
	private JLabel getLblNewLabel_3() {
		if (lblNewLabel_3 == null) {
			lblNewLabel_3 = new JLabel("주소");
			lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_3.setBounds(22, 310, 57, 15);
		}
		return lblNewLabel_3;
	}
	private JLabel getLblNewLabel_4() {
		if (lblNewLabel_4 == null) {
			lblNewLabel_4 = new JLabel("관심분야");
			lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_4.setBounds(108, 402, 57, 15);
		}
		return lblNewLabel_4;
	}
	private JTextField getTfName() {
		if (tfName == null) {
			tfName = new JTextField();
			tfName.setBounds(99, 132, 150, 21);
			tfName.setColumns(10);
		}
		return tfName;
	}
	private JTextField getTfBirth() {
		if (tfBirth == null) {
			tfBirth = new JTextField();
			tfBirth.setBounds(99, 167, 150, 21);
			tfBirth.setColumns(10);
		}
		return tfBirth;
	}
	private JTextField getTfGender() {
		if (tfGender == null) {
			tfGender = new JTextField();
			tfGender.setBounds(99, 202, 150, 21);
			tfGender.setColumns(10);
		}
		return tfGender;
	}
	private JCheckBox getCbDesktop() {
		if (cbDesktop == null) {
			cbDesktop = new JCheckBox("Desktop");
			cbDesktop.setBounds(25, 429, 115, 23);
		}
		return cbDesktop;
	}
	private JCheckBox getCbLaptop() {
		if (cbLaptop == null) {
			cbLaptop = new JCheckBox("Laptop");
			cbLaptop.setBounds(25, 463, 115, 23);
		}
		return cbLaptop;
	}
	private JCheckBox getCbSmartPhone() {
		if (cbSmartPhone == null) {
			cbSmartPhone = new JCheckBox("스마트폰");
			cbSmartPhone.setBounds(25, 498, 115, 23);
		}
		return cbSmartPhone;
	}
	private JCheckBox getCbPeripheralDevice() {
		if (cbPeripheralDevice == null) {
			cbPeripheralDevice = new JCheckBox("주변기기");
			cbPeripheralDevice.setBounds(144, 429, 115, 23);
		}
		return cbPeripheralDevice;
	}
	private JCheckBox getCbEtc() {
		if (cbEtc == null) {
			cbEtc = new JCheckBox("기타");
			cbEtc.setBounds(144, 463, 115, 23);
		}
		return cbEtc;
	}
	private JLabel getLblNewLabel_5() {
		if (lblNewLabel_5 == null) {
			lblNewLabel_5 = new JLabel("이메일");
			lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_5.setBounds(22, 240, 57, 15);
		}
		return lblNewLabel_5;
	}
	private JTextField getTfEmail() {
		if (tfEmail == null) {
			tfEmail = new JTextField();
			tfEmail.setBounds(99, 237, 150, 21);
			tfEmail.setColumns(10);
		}
		return tfEmail;
	}
	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("아이디");
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBounds(22, 30, 57, 15);
		}
		return label;
	}
	private JLabel getLabel_1() {
		if (label_1 == null) {
			label_1 = new JLabel("비밀번호");
			label_1.setHorizontalAlignment(SwingConstants.CENTER);
			label_1.setBounds(22, 65, 57, 15);
		}
		return label_1;
	}
	private JTextField getTfId() {
		if (tfId == null) {
			tfId = new JTextField();
			tfId.setColumns(10);
			tfId.setBounds(99, 27, 150, 21);
		}
		return tfId;
	}
	private JLabel getLabel_2() {
		if (label_2 == null) {
			label_2 = new JLabel("비밀번호 확인");
			label_2.setHorizontalAlignment(SwingConstants.CENTER);
			label_2.setBounds(10, 100, 84, 15);
		}
		return label_2;
	}
	private JPasswordField getPf() {
		if (pf == null) {
			pf = new JPasswordField();
			pf.setBounds(99, 62, 150, 21);
		}
		return pf;
	}
	private JPasswordField getPfConfirm() {
		if (pfConfirm == null) {
			pfConfirm = new JPasswordField();
			pfConfirm.setBounds(99, 97, 150, 21);
		}
		return pfConfirm;
	}
	private JButton getBtnSignUp() {
		if (btnSignUp == null) {
			btnSignUp = new JButton("회원가입");
			btnSignUp.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					byr=new Buyer();
					byr.setId(tfId.getText());
					byr.setPassword(String.valueOf(pf.getPassword()));
					byr.setName(tfName.getText());
					byr.setBirth(tfBirth.getText());
					byr.setGender(tfGender.getText());
					byr.setEmail(tfEmail.getText());
					byr.setTel(tfTel.getText());
					byr.setAddress(ta.getText());
					String pref="";
					
					if(cbDesktop.isSelected()==true) pref+="Desktop\t";
					if(cbLaptop.isSelected()==true) pref+="Laptop\t";
					if(cbPeripheralDevice.isSelected()==true) pref+="주변기기\t";
					if(cbSmartPhone.isSelected()==true) pref+="스마트폰\t";
					if(cbEtc.isSelected()==true) pref+="기타\t";
					byr.setPreference(pref);
					
					if(!String.valueOf(pf.getPassword()).equals(String.valueOf(pfConfirm.getPassword()))) {
						JOptionPane.showMessageDialog(null, "비밀번호가 일치하지 않습니다.");
						return;
					}
					if(byrdba.checkId(byr.getId())==1) {
						JOptionPane.showMessageDialog(null, "이미 존재하는 아이디입니다.");
						return;
					}
					if(tfId.getText().equals("") || String.valueOf(pf.getPassword()).equals("") || tfName.getText().equals("") 
							|| ta.getText().equals("") || tfTel.getText().equals("")) {
						JOptionPane.showMessageDialog(null, "필수입력정보 누락 \n 아이디, 비밀번호, 이름, 전화번호, 주소");
						return;
					}
						
					byrdba.insertId(byr);
					
					tfId.setText("");
					pf.setText("");
					pfConfirm.setText("");
					tfName.setText("");
					tfBirth.setText("");
					tfGender.setText("");
					tfEmail.setText("");
					tfTel.setText("");
					ta.setText("");
					
					JOptionPane.showMessageDialog(null, "회원가입 완료");
					
					LoginView lvw= new LoginView();
					lvw.setVisible(true);
					dispose();
				}
			});
			btnSignUp.setBounds(65, 540, 143, 33);
		}
		return btnSignUp;
	}
	private JTextArea getTa() {
		if (ta == null) {
			ta = new JTextArea();
			ta.setBorder(new LineBorder(new Color(0, 0, 0)));
			ta.setBounds(99, 307, 150, 75);
			ta.setLineWrap(true);
		}
		return ta;
	}
	private JLabel getLabel_3() {
		if (label_3 == null) {
			label_3 = new JLabel("전화번호");
			label_3.setHorizontalAlignment(SwingConstants.CENTER);
			label_3.setBounds(22, 275, 57, 15);
		}
		return label_3;
	}
	private JTextField getTfTel() {
		if (tfTel == null) {
			tfTel = new JTextField();
			tfTel.setColumns(10);
			tfTel.setBounds(99, 272, 150, 21);
		}
		return tfTel;
	}
}
