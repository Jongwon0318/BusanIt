package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import presentation.model.Manager;
import presentation.model.ManagerDBA;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class ManagerSignUp extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JButton btnNewButton;
	private JTextField tfEmpCode;
	private JTextField tfId;
	private JPasswordField pf;
	private JLabel label;
	private JPasswordField pfConfirm;
	private ManagerDBA msudba=new ManagerDBA();
	private Manager mng;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManagerSignUp frame = new ManagerSignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManagerSignUp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 350, 280);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getLblNewLabel_2());
		contentPane.add(getBtnNewButton());
		contentPane.add(getTfEmpCode());
		contentPane.add(getTfId());
		contentPane.add(getPf());
		contentPane.add(getLabel());
		contentPane.add(getPfConfirm());
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("사원코드");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(26, 30, 81, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("아이디");
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1.setBounds(26, 70, 81, 15);
		}
		return lblNewLabel_1;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("비밀번호");
			lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_2.setBounds(26, 110, 81, 15);
		}
		return lblNewLabel_2;
	}
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("계정생성");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mng=new Manager();
					mng.setEmpCode(tfEmpCode.getText());
					mng.setId(tfId.getText());
					mng.setPassword(String.valueOf(pf.getPassword()));

					if(!String.valueOf(pf.getPassword()).equals(String.valueOf(pfConfirm.getPassword()))) {
						JOptionPane.showMessageDialog(null, "비밀번호가 일치하지 않습니다.");
						return;
					}
					if(msudba.checkId(mng.getId())==1) {
						JOptionPane.showMessageDialog(null, "이미 존재하는 아이디입니다.");
						return;
					}
					if(msudba.checkEmpCode(mng.getEmpCode())==1) {
						JOptionPane.showMessageDialog(null, "사원코드 오류");
						return;
					}
					
					msudba.insertId(mng);
					tfEmpCode.setText("");
					tfId.setText("");
					pf.setText("");
					pfConfirm.setText("");
					JOptionPane.showMessageDialog(null, "회원가입 완료");
					
					LoginView lvw= new LoginView();
					lvw.setVisible(true);
					dispose();
				}
			});
			btnNewButton.setBounds(76, 191, 180, 33);
		}
		return btnNewButton;
	}
	private JTextField getTfEmpCode() {
		if (tfEmpCode == null) {
			tfEmpCode = new JTextField();
			tfEmpCode.setBounds(133, 24, 170, 21);
			tfEmpCode.setColumns(10);
		}
		return tfEmpCode;
	}
	private JTextField getTfId() {
		if (tfId == null) {
			tfId = new JTextField();
			tfId.setBounds(133, 64, 170, 21);
			tfId.setColumns(10);
		}
		return tfId;
	}
	private JPasswordField getPf() {
		if (pf == null) {
			pf = new JPasswordField();
			pf.setBounds(133, 104, 170, 21);
		}
		return pf;
	}
	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("비밀번호 확인");
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBounds(26, 150, 81, 15);
		}
		return label;
	}
	private JPasswordField getPfConfirm() {
		if (pfConfirm == null) {
			pfConfirm = new JPasswordField();
			pfConfirm.setBounds(133, 144, 170, 21);
		}
		return pfConfirm;
	}
}
