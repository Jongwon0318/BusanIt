package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import presentation.model.BuyerDBA;
import presentation.model.ManagerDBA;

import javax.swing.JSplitPane;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class LoginView extends JFrame {

	private JPanel contentPane;
	private JSplitPane splitPane;
	private JPanel panel;
	private JPanel panel_1;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JTextField tfId;
	private JPasswordField pf;
	private JButton btnMngLogin;
	private JButton btnByrLogin;
	private JButton btnGuestLogin;
	private JButton btnSignUp;
	ManagerDBA msudba=new ManagerDBA();
	BuyerDBA byrdba=new BuyerDBA();
	private JLabel lblNewLabel_2;
	public static String accessedId;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginView frame = new LoginView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 510);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getSplitPane());
	}
	private JSplitPane getSplitPane() {
		if (splitPane == null) {
			splitPane = new JSplitPane();
			splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
			splitPane.setBounds(0, 0, 284, 481);
			splitPane.setLeftComponent(getPanel());
			splitPane.setRightComponent(getPanel_1());
			splitPane.setDividerLocation(220);
		}
		return splitPane;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(Color.WHITE);
			panel.setLayout(null);
			panel.add(getLblNewLabel_2());
		}
		return panel;
	}
	private JPanel getPanel_1() {
		if (panel_1 == null) {
			panel_1 = new JPanel();
			panel_1.setBackground(Color.WHITE);
			panel_1.setLayout(null);
			panel_1.add(getLblNewLabel());
			panel_1.add(getLblNewLabel_1());
			panel_1.add(getTfId());
			panel_1.add(getPf());
			panel_1.add(getBtnMngLogin());
			panel_1.add(getBtnByrLogin());
			panel_1.add(getBtnGuestLogin());
			panel_1.add(getBtnSignUp());
		}
		return panel_1;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("아이디");
			lblNewLabel.setBounds(38, 29, 57, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("비밀번호");
			lblNewLabel_1.setBounds(38, 65, 57, 15);
		}
		return lblNewLabel_1;
	}
	private JTextField getTfId() {
		if (tfId == null) {
			tfId = new JTextField();
			tfId.setBounds(107, 26, 135, 21);
			tfId.setColumns(10);
		}
		return tfId;
	}
	private JPasswordField getPf() {
		if (pf == null) {
			pf = new JPasswordField();
			pf.setBounds(107, 62, 135, 21);
		}
		return pf;
	}
	private JButton getBtnMngLogin() {
		if (btnMngLogin == null) {
			btnMngLogin = new JButton("관리자 로그인");
			btnMngLogin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String id=tfId.getText();
					String pwd=String.valueOf(pf.getPassword());
					if(msudba.loginConfirm(id,pwd)==0) {
						accessedId=id;
						ManagerView mv=new ManagerView();
						mv.setVisible(true);
						dispose();
					}else {
						JOptionPane.showMessageDialog(null, "아이디 혹은 비밀번호 입력오류");
						return;
					}
				}
			});
			btnMngLogin.setBounds(38, 103, 204, 23);
		}
		return btnMngLogin;
	}
	private JButton getBtnByrLogin() {
		if (btnByrLogin == null) {
			btnByrLogin = new JButton("구매자 로그인");
			btnByrLogin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String id=tfId.getText();
					String pwd=String.valueOf(pf.getPassword());
					if(byrdba.loginConfirm(id,pwd)==0) {
						accessedId=id;
						BuyerView bv=new BuyerView();
						bv.setVisible(true);
						dispose();
					}else {
						JOptionPane.showMessageDialog(null, "아이디 혹은 비밀번호 입력오류");
						return;
					}
				}
			});
			btnByrLogin.setBounds(38, 136, 204, 23);
		}
		return btnByrLogin;
	}
	private JButton getBtnGuestLogin() {
		if (btnGuestLogin == null) {
			btnGuestLogin = new JButton("둘러보기");
			btnGuestLogin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					BuyerView bv=new BuyerView();
					bv.setVisible(true);
					dispose();
				}
			});
			btnGuestLogin.setBounds(38, 169, 204, 23);
		}
		return btnGuestLogin;
	}
	private JButton getBtnSignUp() {
		if (btnSignUp == null) {
			btnSignUp = new JButton("회원가입");
			btnSignUp.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					SignUpView suv=new SignUpView();
					suv.setVisible(true);
					dispose();
				}
			});
			btnSignUp.setBounds(38, 202, 204, 23);
		}
		return btnSignUp;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("");
			lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\it\\Desktop\\화면 구현\\WEB\\Pictures\\photographer.jpg"));
			lblNewLabel_2.setBounds(42, 10, 200, 200);
		}
		return lblNewLabel_2;
	}
}
