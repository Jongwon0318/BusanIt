package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import presentation.model.Buyer;

import javax.swing.JButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Color;

public class BuyerDetail extends JFrame {
	private String num,id,pwd,name,birth,gender,email,tel,addr,pref;
	private JPanel contentPane;
	private JLabel label;
	private JLabel lblId;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel lblNewLabel;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JTextField tfNum;
	private JTextField tfId;
	private JTextField tfPwd;
	private JTextField tfName;
	private JTextField tfBirth;
	private JTextField tfGender;
	private JTextField tfEmail;
	private JTextField tfTel;
	private JTextArea taAddr;
	private JTextArea taPref;


	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					BuyerDetail frame = new BuyerDetail();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */

	
	public BuyerDetail(Buyer byr1) {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				dispose();
			}
		});
		num=byr1.getNum()+"";
		id=byr1.getId();
		pwd=byr1.getPassword();
		name=byr1.getName();
		birth=byr1.getBirth();
		gender=byr1.getGender();
		email=byr1.getEmail();
		tel=byr1.getTel();
		addr=byr1.getAddress();
		pref=byr1.getPreference();
		setBounds(100, 100, 400, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLabel());
		contentPane.add(getLblId());
		contentPane.add(getLabel_2());
		contentPane.add(getLabel_3());
		contentPane.add(getLabel_4());
		contentPane.add(getLblNewLabel());
		contentPane.add(getLabel_5());
		contentPane.add(getLabel_6());
		contentPane.add(getLabel_7());
		contentPane.add(getLabel_8());
		contentPane.add(getTfNum());
		contentPane.add(getTfId());
		contentPane.add(getTfPwd());
		contentPane.add(getTfName());
		contentPane.add(getTfBirth());
		contentPane.add(getTfGender());
		contentPane.add(getTfEmail());
		contentPane.add(getTfTel());
		contentPane.add(getTaAddr());
		contentPane.add(getTaPref());
//		tfNum.setText(num);
//		tfId.setText(id);
//		tfPwd.setText(pwd);
//		tfName.setText(name);
//		tfBirth.setText(birth);
//		tfGender.setText(gender);
//		tfEmail.setText(email);
//		tfTel.setText(tel);
//		taAddr.setText(addr);
//		taPref.setText(pref);
	}
	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("고객번호");
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBounds(30, 30, 85, 15);
		}
		return label;
	}
	private JLabel getLblId() {
		if (lblId == null) {
			lblId = new JLabel("고객 ID");
			lblId.setHorizontalAlignment(SwingConstants.CENTER);
			lblId.setBounds(30, 70, 85, 15);
		}
		return lblId;
	}
	private JLabel getLabel_2() {
		if (label_2 == null) {
			label_2 = new JLabel("고객 비밀번호");
			label_2.setHorizontalAlignment(SwingConstants.CENTER);
			label_2.setBounds(30, 110, 85, 15);
		}
		return label_2;
	}
	private JLabel getLabel_3() {
		if (label_3 == null) {
			label_3 = new JLabel("이름");
			label_3.setHorizontalAlignment(SwingConstants.CENTER);
			label_3.setBounds(30, 150, 85, 15);
		}
		return label_3;
	}
	private JLabel getLabel_4() {
		if (label_4 == null) {
			label_4 = new JLabel("생일");
			label_4.setHorizontalAlignment(SwingConstants.CENTER);
			label_4.setBounds(30, 190, 85, 15);
		}
		return label_4;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("성별");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(30, 230, 85, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLabel_5() {
		if (label_5 == null) {
			label_5 = new JLabel("이메일");
			label_5.setHorizontalAlignment(SwingConstants.CENTER);
			label_5.setBounds(30, 270, 85, 15);
		}
		return label_5;
	}
	private JLabel getLabel_6() {
		if (label_6 == null) {
			label_6 = new JLabel("전화번호");
			label_6.setHorizontalAlignment(SwingConstants.CENTER);
			label_6.setBounds(30, 310, 85, 15);
		}
		return label_6;
	}
	private JLabel getLabel_7() {
		if (label_7 == null) {
			label_7 = new JLabel("주소");
			label_7.setHorizontalAlignment(SwingConstants.CENTER);
			label_7.setBounds(30, 380, 85, 15);
		}
		return label_7;
	}
	private JLabel getLabel_8() {
		if (label_8 == null) {
			label_8 = new JLabel("선호 카테고리");
			label_8.setHorizontalAlignment(SwingConstants.CENTER);
			label_8.setBounds(30, 475, 85, 15);
		}
		return label_8;
	}
	private JTextField getTfNum() {
		if (tfNum == null) {
			tfNum = new JTextField();
			tfNum.setDisabledTextColor(Color.BLACK);
			tfNum.setEnabled(false);
			tfNum.setBounds(130, 27, 197, 21);
			tfNum.setColumns(10);
			tfNum.setText(num);
		}
		return tfNum;
	}
	private JTextField getTfId() {
		if (tfId == null) {
			tfId = new JTextField();
			tfId.setDisabledTextColor(Color.BLACK);
			tfId.setEnabled(false);
			tfId.setColumns(10);
			tfId.setBounds(130, 67, 197, 21);
			tfId.setText(id);
		}
		return tfId;
	}
	private JTextField getTfPwd() {
		if (tfPwd == null) {
			tfPwd = new JTextField();
			tfPwd.setDisabledTextColor(Color.BLACK);
			tfPwd.setEnabled(false);
			tfPwd.setColumns(10);
			tfPwd.setBounds(130, 107, 197, 21);
			tfPwd.setText(pwd);
		}
		return tfPwd;
	}
	private JTextField getTfName() {
		if (tfName == null) {
			tfName = new JTextField();
			tfName.setDisabledTextColor(Color.BLACK);
			tfName.setEnabled(false);
			tfName.setColumns(10);
			tfName.setBounds(130, 147, 197, 21);
			tfName.setText(name);
		}
		return tfName;
	}
	private JTextField getTfBirth() {
		if (tfBirth == null) {
			tfBirth = new JTextField();
			tfBirth.setDisabledTextColor(Color.BLACK);
			tfBirth.setEnabled(false);
			tfBirth.setColumns(10);
			tfBirth.setBounds(130, 187, 197, 21);
			tfBirth.setText(birth);
		}
		return tfBirth;
	}
	private JTextField getTfGender() {
		if (tfGender == null) {
			tfGender = new JTextField();
			tfGender.setDisabledTextColor(Color.BLACK);
			tfGender.setEnabled(false);
			tfGender.setColumns(10);
			tfGender.setBounds(130, 227, 197, 21);
			tfGender.setText(gender);
		}
		return tfGender;
	}
	private JTextField getTfEmail() {
		if (tfEmail == null) {
			tfEmail = new JTextField();
			tfEmail.setDisabledTextColor(Color.BLACK);
			tfEmail.setEnabled(false);
			tfEmail.setColumns(10);
			tfEmail.setBounds(130, 267, 197, 21);
			tfEmail.setText(email);
		}
		return tfEmail;
	}
	private JTextField getTfTel() {
		if (tfTel == null) {
			tfTel = new JTextField();
			tfTel.setDisabledTextColor(Color.BLACK);
			tfTel.setEnabled(false);
			tfTel.setColumns(10);
			tfTel.setBounds(130, 307, 197, 21);
			tfTel.setText(tel);
		}
		return tfTel;
	}
	private JTextArea getTaAddr() {
		if (taAddr == null) {
			taAddr = new JTextArea();
			taAddr.setDisabledTextColor(Color.BLACK);
			taAddr.setSelectionColor(Color.BLACK);
			taAddr.setEnabled(false);
			taAddr.setBounds(127, 346, 200, 84);
			taAddr.setText(addr);
			taAddr.setLineWrap(true);
		}
		return taAddr;
	}
	private JTextArea getTaPref() {
		if (taPref == null) {
			taPref = new JTextArea();
			taPref.setDisabledTextColor(Color.BLACK);
			taPref.setEnabled(false);
			taPref.setBounds(127, 440, 200, 84);
			taPref.setText(pref);
			taPref.setLineWrap(true);
		}
		return taPref;
	}
	
}
