package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import presentation.model.Buyer;
import presentation.model.ManagerDBA;
import presentation.model.WareHouseStock;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class AddingPictureToWareHouseStock extends JFrame {
	
	
	private JPanel contentPane;
	private int pdtNum;
	private JLabel lblNewLabel;
	private JTextField tfPdtNum;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private ImageIcon iic;
	private JLabel pictureLabel;
	private JButton btnNewButton_2;
	
	public static HashMap<Integer,String> pictureHashMap=new HashMap<Integer,String>();
	private File dir=new File("src\\presentation.data");
	private File fPicture=new File(dir,"picturePath.txt");	
	private String filePath;
	
	
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					AddWareHouseStock frame = new AddWareHouseStock();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public AddingPictureToWareHouseStock(WareHouseStock whsNew) {
		Scanner sc=null;
		try {
			if(!fPicture.exists()) {
				fPicture.createNewFile();
			}
			sc=new Scanner(fPicture);
			while(sc.hasNextLine()) {
				String[] tmp=sc.nextLine().split("!");
				pictureHashMap.put(Integer.valueOf(tmp[0]), tmp[1]);
			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pdtNum=whsNew.getProductNum();
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				dispose();
			}
		});
		setBounds(100, 100, 400, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getTfPdtNum());
		contentPane.add(getBtnNewButton());
		contentPane.add(getBtnNewButton_1());
		contentPane.add(getPictureLabel());
		contentPane.add(getBtnNewButton_2());
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("제품번호");
			lblNewLabel.setBounds(29, 10, 57, 15);
		}
		return lblNewLabel;
	}
	private JTextField getTfPdtNum() {
		if (tfPdtNum == null) {
			tfPdtNum = new JTextField();
			tfPdtNum.setEnabled(false);
			tfPdtNum.setBounds(98, 7, 270, 21);
			tfPdtNum.setColumns(10);
			tfPdtNum.setText(pdtNum+"");
		}
		return tfPdtNum;
	}
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("사진 찾기...");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
//					JOptionPane.show
					JFileChooser fc = new JFileChooser();
					if (fc.showSaveDialog(AddingPictureToWareHouseStock.this) == JFileChooser.CANCEL_OPTION) {
						return;// 취소버튼 처리
					}
					File f = fc.getSelectedFile();
					filePath=f.getPath();			
					iic=new ImageIcon(filePath);
					pictureLabel.setIcon(iic);
				}
			});
			btnNewButton.setBounds(29, 266, 121, 23);
		}
		return btnNewButton;
	}
	private JButton getBtnNewButton_1() {
		if (btnNewButton_1 == null) {
			btnNewButton_1 = new JButton("사진 등록");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					pictureHashMap.put(pdtNum,filePath);
					JOptionPane.showMessageDialog(null, "사진저장완료");
					PrintStream ps=null;
					try {
						ps=new PrintStream(fPicture);
						Set<Integer> keys=pictureHashMap.keySet();
						Iterator<Integer> it=keys.iterator();
						while(it.hasNext()) {
							int key=it.next();
							ps.print(key+"!");
							ps.print(pictureHashMap.get(key)+"\n");
						}
						ps.close();
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
					dispose();
				}
			});
			btnNewButton_1.setBounds(162, 266, 97, 23);
		}
		return btnNewButton_1;
	}
	private JLabel getPictureLabel() {
		if (pictureLabel == null) {
			pictureLabel = new JLabel("");
			pictureLabel.setBorder(new LineBorder(new Color(0, 0, 0)));
			pictureLabel.setBounds(29, 35, 339, 221);
		}
		return pictureLabel;
	}
	private JButton getBtnNewButton_2() {
		if (btnNewButton_2 == null) {
			btnNewButton_2 = new JButton("초기화");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					pictureHashMap.clear();
					JOptionPane.showMessageDialog(null, "사진초기화완료");
					dispose();
				}
			});
			btnNewButton_2.setBounds(271, 266, 97, 23);
		}
		return btnNewButton_2;
	}
}
