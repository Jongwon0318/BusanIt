package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import presentation.model.Buyer;
import presentation.model.WareHouseStock;

import javax.swing.JButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Date;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WareHouseStockDetail extends JFrame {
	private int productNum,stockNum, price, quantity, salesNum, empno;
	private String category, name, info;
	private Date stockDate;
	private JPanel contentPane;
	private JLabel label;
	private JLabel lblId;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel lblNewLabel;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JTextField tfPdtNum;
	private JTextField tfSalNum;
	private JTextField tfEmpno;
	private JTextField tfCategory;
	private JTextField tfName;
	private JTextField tfPrice;
	private JTextField tfStockDate;
	private JTextField tfStockNum;
	private JTextArea taInfo;
	private JButton btnNewButton;
	private WareHouseStock whsNew;
	public static JButton btnDispose;
	private JButton btnAddPicture;
	
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					BuyerDetail frame = new BuyerDetail();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */

	
	public WareHouseStockDetail(WareHouseStock whs) {
		addWindowListener(new WindowAdapter() {
			
			@Override
			public void windowClosed(WindowEvent e) {
				dispose();
			}
		});
		productNum=whs.getProductNum();
		salesNum=whs.getSalesNum();
		empno=whs.getEmpno();
		category=whs.getCategory();
		name=whs.getName();
		info=whs.getInfo();
		stockDate=whs.getStockDate();
		price=whs.getPrice();
		quantity=whs.getStockQuantity();
		
		whsNew = new WareHouseStock();
		whsNew=whs;
		
		
		setBounds(100, 100, 400, 560);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLabel());
		contentPane.add(getLblId());
		contentPane.add(getLabel_2());
		contentPane.add(getLabel_3());
		contentPane.add(getLabel_4());
		contentPane.add(getLblNewLabel());
		contentPane.add(getLabel_5());
		contentPane.add(getLabel_6());
		contentPane.add(getLabel_7());
		contentPane.add(getTfPdtNum());
		contentPane.add(getTfSalNum());
		contentPane.add(getTfEmpno());
		contentPane.add(getTfCategory());
		contentPane.add(getTfName());
		contentPane.add(getTfPrice());
		contentPane.add(getTfStockDate());
		contentPane.add(getTfStockNum());
		contentPane.add(getTaInfo());
		contentPane.add(getBtnNewButton());
		contentPane.add(getBtnDispose());
		contentPane.add(getBtnAddPicture());
//		tfNum.setText(num);
//		tfId.setText(id);
//		tfPwd.setText(pwd);
//		tfName.setText(name);
//		tfBirth.setText(birth);
//		tfGender.setText(gender);
//		tfEmail.setText(email);
//		tfTel.setText(tel);
//		taAddr.setText(addr);
//		taPref.setText(pref);
	}
	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("제품 번호");
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBounds(30, 30, 85, 15);
		}
		return label;
	}
	private JLabel getLblId() {
		if (lblId == null) {
			lblId = new JLabel("판매 번호");
			lblId.setHorizontalAlignment(SwingConstants.CENTER);
			lblId.setBounds(30, 70, 85, 15);
		}
		return lblId;
	}
	private JLabel getLabel_2() {
		if (label_2 == null) {
			label_2 = new JLabel("관리자 번호");
			label_2.setHorizontalAlignment(SwingConstants.CENTER);
			label_2.setBounds(30, 110, 85, 15);
		}
		return label_2;
	}
	private JLabel getLabel_3() {
		if (label_3 == null) {
			label_3 = new JLabel("카테고리");
			label_3.setHorizontalAlignment(SwingConstants.CENTER);
			label_3.setBounds(30, 150, 85, 15);
		}
		return label_3;
	}
	private JLabel getLabel_4() {
		if (label_4 == null) {
			label_4 = new JLabel("이름");
			label_4.setHorizontalAlignment(SwingConstants.CENTER);
			label_4.setBounds(30, 190, 85, 15);
		}
		return label_4;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("상세정보");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(30, 387, 85, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLabel_5() {
		if (label_5 == null) {
			label_5 = new JLabel("입고일");
			label_5.setHorizontalAlignment(SwingConstants.CENTER);
			label_5.setBounds(30, 270, 85, 15);
		}
		return label_5;
	}
	private JLabel getLabel_6() {
		if (label_6 == null) {
			label_6 = new JLabel("재고수량");
			label_6.setHorizontalAlignment(SwingConstants.CENTER);
			label_6.setBounds(30, 310, 85, 15);
		}
		return label_6;
	}
	private JLabel getLabel_7() {
		if (label_7 == null) {
			label_7 = new JLabel("가격");
			label_7.setHorizontalAlignment(SwingConstants.CENTER);
			label_7.setBounds(30, 230, 85, 15);
		}
		return label_7;
	}
	private JTextField getTfPdtNum() {
		if (tfPdtNum == null) {
			tfPdtNum = new JTextField();
			tfPdtNum.setDisabledTextColor(Color.BLACK);
			tfPdtNum.setEnabled(false);
			tfPdtNum.setBounds(130, 27, 197, 21);
			tfPdtNum.setColumns(10);
			tfPdtNum.setText(productNum+"");
		}
		return tfPdtNum;
	}
	private JTextField getTfSalNum() {
		if (tfSalNum == null) {
			tfSalNum = new JTextField();
			tfSalNum.setDisabledTextColor(Color.BLACK);
			tfSalNum.setEnabled(false);
			tfSalNum.setColumns(10);
			tfSalNum.setBounds(130, 67, 197, 21);
			tfSalNum.setText(salesNum+"");
		}
		return tfSalNum;
	}
	private JTextField getTfEmpno() {
		if (tfEmpno == null) {
			tfEmpno = new JTextField();
			tfEmpno.setDisabledTextColor(Color.BLACK);
			tfEmpno.setEnabled(false);
			tfEmpno.setColumns(10);
			tfEmpno.setBounds(130, 107, 197, 21);
			tfEmpno.setText(empno+"");
		}
		return tfEmpno;
	}
	private JTextField getTfCategory() {
		if (tfCategory == null) {
			tfCategory = new JTextField();
			tfCategory.setDisabledTextColor(Color.BLACK);
			tfCategory.setEnabled(false);
			tfCategory.setColumns(10);
			tfCategory.setBounds(130, 147, 197, 21);
			tfCategory.setText(category);
		}
		return tfCategory;
	}
	private JTextField getTfName() {
		if (tfName == null) {
			tfName = new JTextField();
			tfName.setDisabledTextColor(Color.BLACK);
			tfName.setEnabled(false);
			tfName.setColumns(10);
			tfName.setBounds(130, 187, 197, 21);
			tfName.setText(name);
		}
		return tfName;
	}
	private JTextField getTfPrice() {
		if (tfPrice == null) {
			tfPrice = new JTextField();
			tfPrice.setDisabledTextColor(Color.BLACK);
			tfPrice.setEnabled(false);
			tfPrice.setColumns(10);
			tfPrice.setBounds(130, 227, 197, 21);
			tfPrice.setText(price+"");
		}
		return tfPrice;
	}
	private JTextField getTfStockDate() {
		if (tfStockDate == null) {
			tfStockDate = new JTextField();
			tfStockDate.setDisabledTextColor(Color.BLACK);
			tfStockDate.setEnabled(false);
			tfStockDate.setColumns(10);
			tfStockDate.setBounds(130, 267, 197, 21);
			tfStockDate.setText(stockDate+"");
		}
		return tfStockDate;
	}
	private JTextField getTfStockNum() {
		if (tfStockNum == null) {
			tfStockNum = new JTextField();
			tfStockNum.setDisabledTextColor(Color.BLACK);
			tfStockNum.setEnabled(false);
			tfStockNum.setColumns(10);
			tfStockNum.setBounds(130, 307, 197, 21);
			tfStockNum.setText(stockNum+"");
			tfStockNum.setText(quantity+"");
		}
		return tfStockNum;
	}
	private JTextArea getTaInfo() {
		if (taInfo == null) {
			taInfo = new JTextArea();
			taInfo.setDisabledTextColor(Color.BLACK);
			taInfo.setSelectionColor(Color.BLACK);
			taInfo.setEnabled(false);
			taInfo.setBounds(127, 351, 200, 91);
			taInfo.setText(info);
			taInfo.setLineWrap(true);
		}
		return taInfo;
	}
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("입고 추가");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					AddingWareHouseStock awhs=new AddingWareHouseStock(whsNew);
					awhs.setVisible(true);
				}
			});
			btnNewButton.setBounds(12, 458, 119, 47);
		}
		return btnNewButton;
	}
	private JButton getBtnDispose() {
		if (btnDispose == null) {
			btnDispose = new JButton("닫기");
			btnDispose.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			btnDispose.setBounds(254, 458, 119, 47);
		}
		return btnDispose;
	}
	private JButton getBtnAddPicture() {
		if (btnAddPicture == null) {
			btnAddPicture = new JButton("사진 추가");
			btnAddPicture.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					AddingPictureToWareHouseStock aptwhs=new AddingPictureToWareHouseStock(whsNew);
					aptwhs.setVisible(true);
				}
			});
			btnAddPicture.setBounds(133, 458, 119, 47);
		}
		return btnAddPicture;
	}
}
