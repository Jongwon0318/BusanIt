package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import java.awt.Color;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import presentation.model.Buyer;
import presentation.model.BuyerDBA;
import presentation.model.ShoppingBasketDBA;
import presentation.model.WareHouseStock;
import presentation.model.WareHouseStockDBA;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JSplitPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class BuyerView extends JFrame {

	private JPanel contentPane;
	private JTabbedPane tabbedPane;
	private JPanel 제품;
	private JPanel 시작페이지;
	private JPanel 장바구니;
	private JPanel 회원정보;
	private JLabel lblNewLabel;
	private JLabel lblId;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JTextField tfBuyerNo;
	private JTextField tfBuyerId;
	private JTextField tfBuyerName;
	private JPasswordField pf;
	private JTextField tfBuyerBirth;
	private JTextField tfBuyerGender;
	private JTextField tfBuyerEmail;
	private JTextField tfBuyerTel;
	private JTextArea taBuyerAddr;
	private JCheckBox cb1;
	private JCheckBox cb3;
	private JCheckBox cb4;
	private JCheckBox cb2;
	private JCheckBox cb5;
	private JScrollPane scrollPane;
	private JTable productTable;
	private JScrollPane scrollPane_1;
	public JTable shoppingBasketTable;
	private JSplitPane splitPane;
	private JSplitPane splitPane_1;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private BuyerDBA bdba = new BuyerDBA();
	private ArrayList<WareHouseStock> wal = new ArrayList<WareHouseStock>();
	private WareHouseStockDBA whsdba = new WareHouseStockDBA();
	private File dir = new File("src\\presentation.data");
	private File fPicture = new File(dir, "picturePath.txt");
	public static HashMap<Integer, Integer> sbMap1 = new HashMap<Integer, Integer>();
	private JButton btnBringSB;
	private JLabel lblNewLabel_3;
	private JTextField tfTotalPrice;
	private JLabel lblNewLabel_4;
	private JButton btnNewButton_1;
	private ShoppingBasketDBA sbdba=new ShoppingBasketDBA();
	
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					BuyerView frame = new BuyerView();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public BuyerView() {
		Scanner sc = null;
		try {
			sc = new Scanner(fPicture);
			while (sc.hasNextLine()) {
				String[] tmp = sc.nextLine().split("!");
				AddingPictureToWareHouseStock.pictureHashMap.put(Integer.valueOf(tmp[0]), tmp[1]);
			}
			sc.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 742);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getTabbedPane());
		Buyer byr = bdba.getBuyerInfo(bdba.getBuyerNo());
		tfBuyerNo.setText(byr.getNum() + "");
		tfBuyerId.setText(byr.getId());
		pf.setText(byr.getPassword());
		tfBuyerName.setText(byr.getName());
		tfBuyerBirth.setText(byr.getBirth());
		tfBuyerGender.setText(byr.getGender());
		tfBuyerEmail.setText(byr.getEmail());
		tfBuyerTel.setText(byr.getTel());
		taBuyerAddr.setText(byr.getAddress());
		if (byr.getPreference().contains("Desktop")) {
			cb1.doClick();
		}
		if (byr.getPreference().contains("주변기기")) {
			cb2.doClick();
		}
		if (byr.getPreference().contains("Laptop")) {
			cb3.doClick();
		}
		if (byr.getPreference().contains("기타")) {
			cb4.doClick();
		}
		if (byr.getPreference().contains("스마트폰")) {
			cb5.doClick();
		}
	}

	private JTabbedPane getTabbedPane() {
		if (tabbedPane == null) {
			tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane.setBounds(0, 0, 1008, 703);
			tabbedPane.addTab("시작페이지", null, get시작페이지(), null);
			tabbedPane.addTab("제품", null, get제품(), null);
			tabbedPane.addTab("장바구니", null, get장바구니(), null);
			tabbedPane.addTab("회원정보", null, get회원정보(), null);
		}
		return tabbedPane;
	}

	private JPanel get제품() {
		if (제품 == null) {
			제품 = new JPanel();
			제품.setBackground(Color.WHITE);
			제품.setLayout(null);
			제품.add(getScrollPane());
		}
		return 제품;
	}

	private JPanel get시작페이지() {
		if (시작페이지 == null) {
			시작페이지 = new JPanel();
			시작페이지.setLayout(null);
			시작페이지.add(getSplitPane());
		}
		return 시작페이지;
	}

	private JPanel get장바구니() {
		if (장바구니 == null) {
			장바구니 = new JPanel();
			장바구니.setBackground(Color.WHITE);
			장바구니.setLayout(null);
			장바구니.add(getScrollPane_1());
			장바구니.add(getLblNewLabel_3());
			장바구니.add(getTfTotalPrice());
			장바구니.add(getLblNewLabel_4());
			장바구니.add(getBtnNewButton_1());
		}
		return 장바구니;
	}

	private JPanel get회원정보() {
		if (회원정보 == null) {
			회원정보 = new JPanel();
			회원정보.setBackground(Color.WHITE);
			회원정보.setLayout(null);
			회원정보.add(getLblNewLabel());
			회원정보.add(getLblId());
			회원정보.add(getLabel());
			회원정보.add(getLabel_1());
			회원정보.add(getLabel_2());
			회원정보.add(getLabel_3());
			회원정보.add(getLabel_4());
			회원정보.add(getLabel_5());
			회원정보.add(getLabel_6());
			회원정보.add(getLabel_7());
			회원정보.add(getTfBuyerNo());
			회원정보.add(getTfBuyerId());
			회원정보.add(getTfBuyerName());
			회원정보.add(getPf());
			회원정보.add(getTfBuyerBirth());
			회원정보.add(getTfBuyerGender());
			회원정보.add(getTfBuyerEmail());
			회원정보.add(getTfBuyerTel());
			회원정보.add(getTaBuyerAddr());
			회원정보.add(getCb1());
			회원정보.add(getCb3());
			회원정보.add(getCb4());
			회원정보.add(getCb2());
			회원정보.add(getCb5());
		}
		return 회원정보;
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("고객번호");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(304, 55, 104, 15);
		}
		return lblNewLabel;
	}

	private JLabel getLblId() {
		if (lblId == null) {
			lblId = new JLabel("ID");
			lblId.setHorizontalAlignment(SwingConstants.CENTER);
			lblId.setBounds(304, 105, 104, 15);
		}
		return lblId;
	}

	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("비밀번호");
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBounds(304, 155, 104, 15);
		}
		return label;
	}

	private JLabel getLabel_1() {
		if (label_1 == null) {
			label_1 = new JLabel("이름");
			label_1.setHorizontalAlignment(SwingConstants.CENTER);
			label_1.setBounds(304, 205, 104, 15);
		}
		return label_1;
	}

	private JLabel getLabel_2() {
		if (label_2 == null) {
			label_2 = new JLabel("생일");
			label_2.setHorizontalAlignment(SwingConstants.CENTER);
			label_2.setBounds(304, 255, 104, 15);
		}
		return label_2;
	}

	private JLabel getLabel_3() {
		if (label_3 == null) {
			label_3 = new JLabel("성별");
			label_3.setHorizontalAlignment(SwingConstants.CENTER);
			label_3.setBounds(304, 305, 104, 15);
		}
		return label_3;
	}

	private JLabel getLabel_4() {
		if (label_4 == null) {
			label_4 = new JLabel("이메일");
			label_4.setHorizontalAlignment(SwingConstants.CENTER);
			label_4.setBounds(304, 355, 104, 15);
		}
		return label_4;
	}

	private JLabel getLabel_5() {
		if (label_5 == null) {
			label_5 = new JLabel("전화번호");
			label_5.setHorizontalAlignment(SwingConstants.CENTER);
			label_5.setBounds(304, 405, 104, 15);
		}
		return label_5;
	}

	private JLabel getLabel_6() {
		if (label_6 == null) {
			label_6 = new JLabel("주소");
			label_6.setHorizontalAlignment(SwingConstants.CENTER);
			label_6.setBounds(304, 455, 104, 15);
		}
		return label_6;
	}

	private JLabel getLabel_7() {
		if (label_7 == null) {
			label_7 = new JLabel("선호 카테고리");
			label_7.setHorizontalAlignment(SwingConstants.CENTER);
			label_7.setBounds(304, 537, 104, 15);
		}
		return label_7;
	}

	private JTextField getTfBuyerNo() {
		if (tfBuyerNo == null) {
			tfBuyerNo = new JTextField();
			tfBuyerNo.setEnabled(false);
			tfBuyerNo.setBorder(new LineBorder(new Color(0, 0, 0)));
			tfBuyerNo.setBackground(Color.WHITE);
			tfBuyerNo.setBounds(420, 52, 204, 21);
			tfBuyerNo.setColumns(10);
		}
		return tfBuyerNo;
	}

	private JTextField getTfBuyerId() {
		if (tfBuyerId == null) {
			tfBuyerId = new JTextField();
			tfBuyerId.setEnabled(false);
			tfBuyerId.setBorder(new LineBorder(new Color(0, 0, 0)));
			tfBuyerId.setBackground(Color.WHITE);
			tfBuyerId.setColumns(10);
			tfBuyerId.setBounds(420, 102, 204, 21);
		}
		return tfBuyerId;
	}

	private JTextField getTfBuyerName() {
		if (tfBuyerName == null) {
			tfBuyerName = new JTextField();
			tfBuyerName.setEnabled(false);
			tfBuyerName.setBorder(new LineBorder(new Color(0, 0, 0)));
			tfBuyerName.setBackground(Color.WHITE);
			tfBuyerName.setColumns(10);
			tfBuyerName.setBounds(420, 202, 204, 21);
		}
		return tfBuyerName;
	}

	private JPasswordField getPf() {
		if (pf == null) {
			pf = new JPasswordField();
			pf.setEnabled(false);
			pf.setBorder(new LineBorder(new Color(0, 0, 0)));
			pf.setBackground(Color.WHITE);
			pf.setBounds(420, 152, 204, 21);
		}
		return pf;
	}

	private JTextField getTfBuyerBirth() {
		if (tfBuyerBirth == null) {
			tfBuyerBirth = new JTextField();
			tfBuyerBirth.setEnabled(false);
			tfBuyerBirth.setBorder(new LineBorder(new Color(0, 0, 0)));
			tfBuyerBirth.setBackground(Color.WHITE);
			tfBuyerBirth.setColumns(10);
			tfBuyerBirth.setBounds(420, 252, 204, 21);
		}
		return tfBuyerBirth;
	}

	private JTextField getTfBuyerGender() {
		if (tfBuyerGender == null) {
			tfBuyerGender = new JTextField();
			tfBuyerGender.setEnabled(false);
			tfBuyerGender.setBorder(new LineBorder(new Color(0, 0, 0)));
			tfBuyerGender.setBackground(Color.WHITE);
			tfBuyerGender.setColumns(10);
			tfBuyerGender.setBounds(420, 302, 204, 21);
		}
		return tfBuyerGender;
	}

	private JTextField getTfBuyerEmail() {
		if (tfBuyerEmail == null) {
			tfBuyerEmail = new JTextField();
			tfBuyerEmail.setEnabled(false);
			tfBuyerEmail.setBorder(new LineBorder(new Color(0, 0, 0)));
			tfBuyerEmail.setBackground(Color.WHITE);
			tfBuyerEmail.setColumns(10);
			tfBuyerEmail.setBounds(420, 352, 204, 21);
		}
		return tfBuyerEmail;
	}

	private JTextField getTfBuyerTel() {
		if (tfBuyerTel == null) {
			tfBuyerTel = new JTextField();
			tfBuyerTel.setEnabled(false);
			tfBuyerTel.setBorder(new LineBorder(new Color(0, 0, 0)));
			tfBuyerTel.setBackground(Color.WHITE);
			tfBuyerTel.setColumns(10);
			tfBuyerTel.setBounds(420, 402, 204, 21);
		}
		return tfBuyerTel;
	}

	private JTextArea getTaBuyerAddr() {
		if (taBuyerAddr == null) {
			taBuyerAddr = new JTextArea();
			taBuyerAddr.setEnabled(false);
			taBuyerAddr.setBorder(new LineBorder(new Color(0, 0, 0)));
			taBuyerAddr.setBackground(Color.WHITE);
			taBuyerAddr.setBounds(420, 436, 204, 54);
			taBuyerAddr.setLineWrap(true);
		}
		return taBuyerAddr;
	}

	private JCheckBox getCb1() {
		if (cb1 == null) {
			cb1 = new JCheckBox("Desktop");
			cb1.setBounds(416, 508, 115, 23);
		}
		return cb1;
	}

	private JCheckBox getCb3() {
		if (cb3 == null) {
			cb3 = new JCheckBox("Laptop");
			cb3.setBounds(416, 542, 115, 23);
		}
		return cb3;
	}

	private JCheckBox getCb4() {
		if (cb4 == null) {
			cb4 = new JCheckBox("기타");
			cb4.setBounds(535, 542, 115, 23);
		}
		return cb4;
	}

	private JCheckBox getCb2() {
		if (cb2 == null) {
			cb2 = new JCheckBox("주변기기");
			cb2.setBounds(535, 508, 115, 23);
		}
		return cb2;
	}

	private JCheckBox getCb5() {
		if (cb5 == null) {
			cb5 = new JCheckBox("스마트폰");
			cb5.setBounds(416, 577, 115, 23);
		}
		return cb5;
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(12, 10, 979, 654);
			scrollPane.setColumnHeaderView(getProductTable());
			scrollPane.setViewportView(getProductTable());
		}
		return scrollPane;
	}

	private JTable getProductTable() {
		if (productTable == null) {
			productTable = new JTable();

			wal = whsdba.getWareHouseStockList();

			String[] cols = { "사진", "카테고리", "이름", "상세정보", "입고일", "가격", "재고수량" };
			DefaultTableModel dt = new DefaultTableModel(cols, wal.size());

			productTable.setModel(dt);
			productTable.setRowHeight(100);
			productTable.getColumnModel().getColumn(0).setPreferredWidth(80);
			productTable.getColumnModel().getColumn(1).setPreferredWidth(62);
			productTable.getColumnModel().getColumn(2).setPreferredWidth(70);
			productTable.getColumnModel().getColumn(3).setPreferredWidth(165);
			productTable.getColumnModel().getColumn(4).setPreferredWidth(70);
			productTable.getColumnModel().getColumn(5).setPreferredWidth(70);
			productTable.getColumnModel().getColumn(6).setPreferredWidth(40);

//			AddingPictureToWareHouseStock.pictureHashMap.get(wal.get(i).getProductNum());

			for (int i = 0; i < wal.size(); i++) {
				dt.setValueAt("눌러서 확인하기", i, 0);
				dt.setValueAt(wal.get(i).getCategory(), i, 1);
				dt.setValueAt(wal.get(i).getName(), i, 2);
				dt.setValueAt(wal.get(i).getInfo(), i, 3);
				dt.setValueAt(wal.get(i).getStockDate(), i, 4);
				dt.setValueAt(wal.get(i).getPrice(), i, 5);
				dt.setValueAt(wal.get(i).getStockQuantity(), i, 6);
			}

			productTable.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					int select = productTable.getSelectedRow();
					ProductDetail pdt = new ProductDetail(wal.get(select));
					pdt.setVisible(true);
				}
			});

		}
		return productTable;
	}

	private JScrollPane getScrollPane_1() {
		if (scrollPane_1 == null) {
			scrollPane_1 = new JScrollPane();
			scrollPane_1.setBounds(12, 10, 979, 591);
			scrollPane_1.setColumnHeaderView(getShoppingBasketTable());
			scrollPane_1.setViewportView(getShoppingBasketTable());
			scrollPane_1.setRowHeaderView(getBtnBringSB());
		}
		return scrollPane_1;
	}

	private JTable getShoppingBasketTable() {
		if (shoppingBasketTable == null) {
			shoppingBasketTable = new JTable();
		}
		return shoppingBasketTable;
	}

	private JSplitPane getSplitPane() {
		if (splitPane == null) {
			splitPane = new JSplitPane();
			splitPane.setBounds(12, 10, 979, 654);
			splitPane.setRightComponent(getSplitPane_1());
			splitPane.setLeftComponent(getTable_4());
			splitPane.setDividerLocation(250);
		}
		return splitPane;
	}

	private JSplitPane getSplitPane_1() {
		if (splitPane_1 == null) {
			splitPane_1 = new JSplitPane();
			splitPane_1.setOrientation(JSplitPane.VERTICAL_SPLIT);
			splitPane_1.setLeftComponent(getTable_2());
			splitPane_1.setRightComponent(getTable_3());
			splitPane_1.setDividerLocation(325);
		}
		return splitPane_1;
	}

	private JTable getTable_2() {
		if (table_2 == null) {
			table_2 = new JTable();
		}
		return table_2;
	}

	private JTable getTable_3() {
		if (table_3 == null) {
			table_3 = new JTable();
		}
		return table_3;
	}

	private JTable getTable_4() {
		if (table_4 == null) {
			table_4 = new JTable();
		}
		return table_4;
	}

	private JButton getBtnBringSB() {
		if (btnBringSB == null) {
			btnBringSB = new JButton("불러오기");
			btnBringSB.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ArrayList<WareHouseStock> walSB = new ArrayList<WareHouseStock>();

					Set<Integer> keys = sbMap1.keySet();
					Iterator<Integer> it = keys.iterator();

					while (it.hasNext()) {
						walSB.add(whsdba.getOrderedWareHouseStock(it.next()));
					}

					String[] cols = { "카테고리", "이름", "상세정보", "입고일", "가격", "재고수량", "구매수량" };
					DefaultTableModel dt = new DefaultTableModel(cols, walSB.size());

					shoppingBasketTable.setModel(dt);
					shoppingBasketTable.setRowHeight(100);
					shoppingBasketTable.getColumnModel().getColumn(0).setPreferredWidth(80);
					shoppingBasketTable.getColumnModel().getColumn(1).setPreferredWidth(62);
					shoppingBasketTable.getColumnModel().getColumn(2).setPreferredWidth(70);
					shoppingBasketTable.getColumnModel().getColumn(3).setPreferredWidth(165);
					shoppingBasketTable.getColumnModel().getColumn(4).setPreferredWidth(70);
					shoppingBasketTable.getColumnModel().getColumn(5).setPreferredWidth(70);
					shoppingBasketTable.getColumnModel().getColumn(6).setPreferredWidth(40);

					for (int i = 0; i < walSB.size(); i++) {
						dt.setValueAt(walSB.get(i).getCategory(), i, 0);
						dt.setValueAt(walSB.get(i).getName(), i, 1);
						dt.setValueAt(walSB.get(i).getInfo(), i, 2);
						dt.setValueAt(walSB.get(i).getStockDate(), i, 3);
						dt.setValueAt(walSB.get(i).getPrice(), i, 4);
						dt.setValueAt(walSB.get(i).getStockQuantity(), i, 5);
						dt.setValueAt(sbMap1.get(walSB.get(i).getProductNum()), i, 6);
					}
					int totalPrice = 0;
					for (int i = 0; i < walSB.size(); i++) {
						totalPrice += walSB.get(i).getPrice() * sbMap1.get(walSB.get(i).getProductNum());
					}
					tfTotalPrice.setText(String.valueOf(totalPrice));
				}
			});
		}
		return btnBringSB;
	}

	class ProductDetail extends JFrame {
		private int productNum, stockNum, price, quantity, salesNum, empno;
		private String category, name, info;
		private Date stockDate;
		private JPanel contentPane;
		private JLabel label_3;
		private JLabel label_4;
		private JLabel lblNewLabel;
		private JLabel label_5;
		private JLabel label_6;
		private JLabel label_7;
		private JTextField tfCategory;
		private JTextField tfName;
		private JTextField tfPrice;
		private JTextField tfStockDate;
		private JTextField tfStockNum;
		private JTextArea taInfo;
		private JButton btnNewButton;
		private WareHouseStock whsNew;
		public JButton btnDispose;
		private JLabel label;
		private JLabel productPictureLabel;
		private JLabel lblNewLabel_1;
		private JTextField tfBuyingNum;
		private JLabel lblNewLabel_2;

		/**
		 * Launch the application.
		 */
//		public static void main(String[] args) {
//			EventQueue.invokeLater(new Runnable() {
//				public void run() {
//					try {
//						BuyerDetail frame = new BuyerDetail();
//						frame.setVisible(true);
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				}
//			});
//		}

		/**
		 * Create the frame.
		 */

		public ProductDetail(WareHouseStock whs) {
			addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosed(WindowEvent e) {
					dispose();
				}
			});

			productNum = whs.getProductNum();
			salesNum = whs.getSalesNum();
			empno = whs.getEmpno();
			category = whs.getCategory();
			name = whs.getName();
			info = whs.getInfo();
			stockDate = whs.getStockDate();
			price = whs.getPrice();
			quantity = whs.getStockQuantity();

			whsNew = new WareHouseStock();
			whsNew = whs;

			setBounds(100, 100, 400, 700);
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			setContentPane(contentPane);
			contentPane.setLayout(null);
			contentPane.add(getLabel_3());
			contentPane.add(getLabel_4());
			contentPane.add(getLblNewLabel());
			contentPane.add(getLabel_5());
			contentPane.add(getLabel_6());
			contentPane.add(getLabel_7());
			contentPane.add(getTfCategory());
			contentPane.add(getTfName());
			contentPane.add(getTfPrice());
			contentPane.add(getTfStockDate());
			contentPane.add(getTfStockNum());
			contentPane.add(getTaInfo());
			contentPane.add(addShoppingBasket());
			contentPane.add(getLabel_1());
			contentPane.add(getLabel_1_1());
			contentPane.add(getLabel_1_2());
			contentPane.add(getTfBuyingNum());
			contentPane.add(getLabel_1_3());
//			tfNum.setText(num);
//			tfId.setText(id);
//			tfPwd.setText(pwd);
//			tfName.setText(name);
//			tfBirth.setText(birth);
//			tfGender.setText(gender);
//			tfEmail.setText(email);
//			tfTel.setText(tel);
//			taAddr.setText(addr);
//			taPref.setText(pref);

		}

		private JLabel getLabel_3() {
			if (label_3 == null) {
				label_3 = new JLabel("카테고리");
				label_3.setHorizontalAlignment(SwingConstants.CENTER);
				label_3.setBounds(30, 206, 85, 15);
			}
			return label_3;
		}

		private JLabel getLabel_4() {
			if (label_4 == null) {
				label_4 = new JLabel("이름");
				label_4.setHorizontalAlignment(SwingConstants.CENTER);
				label_4.setBounds(30, 246, 85, 15);
			}
			return label_4;
		}

		private JLabel getLblNewLabel() {
			if (lblNewLabel == null) {
				lblNewLabel = new JLabel("상세정보");
				lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel.setBounds(30, 443, 85, 15);
			}
			return lblNewLabel;
		}

		private JLabel getLabel_5() {
			if (label_5 == null) {
				label_5 = new JLabel("입고일");
				label_5.setHorizontalAlignment(SwingConstants.CENTER);
				label_5.setBounds(30, 326, 85, 15);
			}
			return label_5;
		}

		private JLabel getLabel_6() {
			if (label_6 == null) {
				label_6 = new JLabel("재고수량");
				label_6.setHorizontalAlignment(SwingConstants.CENTER);
				label_6.setBounds(30, 366, 85, 15);
			}
			return label_6;
		}

		private JLabel getLabel_7() {
			if (label_7 == null) {
				label_7 = new JLabel("가격");
				label_7.setHorizontalAlignment(SwingConstants.CENTER);
				label_7.setBounds(30, 286, 85, 15);
			}
			return label_7;
		}

		private JTextField getTfCategory() {
			if (tfCategory == null) {
				tfCategory = new JTextField();
				tfCategory.setDisabledTextColor(Color.BLACK);
				tfCategory.setEnabled(false);
				tfCategory.setColumns(10);
				tfCategory.setBounds(130, 203, 197, 21);
				tfCategory.setText(category);
			}
			return tfCategory;
		}

		private JTextField getTfName() {
			if (tfName == null) {
				tfName = new JTextField();
				tfName.setDisabledTextColor(Color.BLACK);
				tfName.setEnabled(false);
				tfName.setColumns(10);
				tfName.setBounds(130, 243, 197, 21);
				tfName.setText(name);
			}
			return tfName;
		}

		private JTextField getTfPrice() {
			if (tfPrice == null) {
				tfPrice = new JTextField();
				tfPrice.setDisabledTextColor(Color.BLACK);
				tfPrice.setEnabled(false);
				tfPrice.setColumns(10);
				tfPrice.setBounds(130, 283, 197, 21);
				tfPrice.setText(price + "");
			}
			return tfPrice;
		}

		private JTextField getTfStockDate() {
			if (tfStockDate == null) {
				tfStockDate = new JTextField();
				tfStockDate.setDisabledTextColor(Color.BLACK);
				tfStockDate.setEnabled(false);
				tfStockDate.setColumns(10);
				tfStockDate.setBounds(130, 323, 197, 21);
				tfStockDate.setText(stockDate + "");
			}
			return tfStockDate;
		}

		private JTextField getTfStockNum() {
			if (tfStockNum == null) {
				tfStockNum = new JTextField();
				tfStockNum.setDisabledTextColor(Color.BLACK);
				tfStockNum.setEnabled(false);
				tfStockNum.setColumns(10);
				tfStockNum.setBounds(130, 363, 197, 21);
				tfStockNum.setText(stockNum + "");
				tfStockNum.setText(quantity + "");
			}
			return tfStockNum;
		}

		private JTextArea getTaInfo() {
			if (taInfo == null) {
				taInfo = new JTextArea();
				taInfo.setDisabledTextColor(Color.BLACK);
				taInfo.setSelectionColor(Color.BLACK);
				taInfo.setEnabled(false);
				taInfo.setBounds(127, 407, 200, 91);
				taInfo.setText(info);
				taInfo.setLineWrap(true);
			}
			return taInfo;
		}

		private JButton addShoppingBasket() {
			if (btnDispose == null) {
				btnDispose = new JButton("장바구니에 추가");
				btnDispose.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						BuyerView.sbMap1.put(productNum, Integer.parseInt(tfBuyingNum.getText()));
						JOptionPane.showMessageDialog(null, "장바구니에 추가 완료");
					}
				});
				btnDispose.setBounds(185, 584, 139, 47);
			}
			return btnDispose;
		}

		private JLabel getLabel_1() {
			if (label == null) {
				label = new JLabel("사진");
				label.setHorizontalAlignment(SwingConstants.CENTER);
				label.setBounds(30, 104, 85, 15);
			}
			return label;
		}

		private JLabel getLabel_1_1() {
			if (productPictureLabel == null) {
				productPictureLabel = new JLabel("");
				productPictureLabel.setBorder(new LineBorder(new Color(0, 0, 0)));
				productPictureLabel.setBounds(130, 10, 197, 183);
				productPictureLabel
						.setIcon(new ImageIcon(AddingPictureToWareHouseStock.pictureHashMap.get(productNum)));
			}
			return productPictureLabel;
		}

		private JLabel getLabel_1_2() {
			if (lblNewLabel_1 == null) {
				lblNewLabel_1 = new JLabel("구매수량");
				lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel_1.setBounds(61, 541, 57, 15);
			}
			return lblNewLabel_1;
		}

		private JTextField getTfBuyingNum() {
			if (tfBuyingNum == null) {
				tfBuyingNum = new JTextField();
				tfBuyingNum.setBounds(127, 538, 176, 21);
				tfBuyingNum.setColumns(10);
			}
			return tfBuyingNum;
		}

		private JLabel getLabel_1_3() {
			if (lblNewLabel_2 == null) {
				lblNewLabel_2 = new JLabel("개");
				lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
				lblNewLabel_2.setBounds(315, 541, 57, 15);
			}
			return lblNewLabel_2;
		}
	}

	private JLabel getLblNewLabel_3() {
		if (lblNewLabel_3 == null) {
			lblNewLabel_3 = new JLabel("총구매금액");
			lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_3.setBounds(555, 625, 84, 15);
		}
		return lblNewLabel_3;
	}

	private JTextField getTfTotalPrice() {
		if (tfTotalPrice == null) {
			tfTotalPrice = new JTextField();
			tfTotalPrice.setEnabled(false);
			tfTotalPrice.setBounds(651, 622, 143, 21);
			tfTotalPrice.setColumns(10);
		}
		return tfTotalPrice;
	}

	private JLabel getLblNewLabel_4() {
		if (lblNewLabel_4 == null) {
			lblNewLabel_4 = new JLabel("원");
			lblNewLabel_4.setBounds(810, 625, 22, 15);
		}
		return lblNewLabel_4;
	}

	private JButton getBtnNewButton_1() {
		if (btnNewButton_1 == null) {
			btnNewButton_1 = new JButton("구매요청");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					ArrayList<WareHouseStock> walSB = new ArrayList<WareHouseStock>();
					
					Set <Integer> keys = sbMap1.keySet();
					Iterator <Integer> it = keys.iterator();
					
					while(it.hasNext()) {
						walSB.add(whsdba.getOrderedWareHouseStock(it.next()));
					}
					
					int buyingProductNum=0;
					int[] tmp=new int[walSB.size()];
					for (int i = 0; i < walSB.size(); i++) {
						buyingProductNum=walSB.get(i).getProductNum();
						tmp[i]=buyingProductNum;
					}
					sbdba.addBuyingData(tmp);					
				}
			});
			btnNewButton_1.setBounds(844, 611, 147, 39);
		}
		return btnNewButton_1;
	}
}
