package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import presentation.model.Buyer;
import presentation.model.ManagerDBA;
import presentation.model.SalesStock;
import presentation.model.SalesStockDBA;
import presentation.model.ShoppingBasket;
import presentation.model.ShoppingBasketDBA;
import presentation.model.WareHouseStock;
import presentation.model.WareHouseStockDBA;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class ManagerView extends JFrame {

	private JPanel contentPane;
	private JTabbedPane tabbedPane;
	private JPanel 재고등록;
	private JPanel 구매요청관리;
	private JPanel 회원정보관리;
	private JPanel 발주처리;
	private JScrollPane scrollPane;
	private JTable buyerTable;
	private JButton btnNewButton;
	private JButton button;
	private JButton button_1;
	private JTextField tfSearch;
	private JComboBox comboBox;
	private ManagerDBA mdba = new ManagerDBA();
	private ArrayList<Buyer> bal;
	private PrintStream ps;
	private JPanel 재고관리;
	private JScrollPane scrollPane_1;
	public static JButton btnStockViewAll;
	private JButton button_3;
	private WareHouseStockDBA whsdba = new WareHouseStockDBA();
	private ArrayList<WareHouseStock> wal;
	public JTable productTable;
	private JLabel label;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_8;
	private JTextField tfPdtQuantity;
	private JTextField tfPdtPrice;
	private JTextField tfPdtName;
	private JCheckBox cbDesktop;
	private JCheckBox cbLaptop;
	private JCheckBox cbPeripheralDevice;
	private JCheckBox cbEtc;
	private JCheckBox cbSmartPhone;
	private JTextArea taPdtInfo;
	private JButton button_5;
	private JScrollPane scrollPane_2;
	private JButton btnBuyViewAll;
	private JButton button_8;
	private JTextField tfBuyingNum;
	private JTextField tfPdtNum;
	private JTextField tfEmpno;
	private JTextField tfStockDate;
	private JLabel label_1;
	private JTextField tfOrder1;
	private JLabel label_2;
	private JTextField tfOrder2;
	private JLabel label_3;
	private JTextField tfOrder3;
	private JLabel label_4;
	private JTextField tfOrder4;
	private JLabel label_5;
	private JTextField tfOrder5;
	private JLabel label_6;
	private JTextField tfOrder6;
	private JLabel label_7;
	private JTextField tfOrder7;
	private JLabel label_8;
	private JTextField tfOrder8;
	private JLabel label_9;
	private JTextArea taOrder;
	private JTextField tfOrderPdtNum;
	private JButton btnNewButton_2;
	private JLabel lblNewLabel_6;
	private JLabel label_10;
	private JTextField tfOrderPdtQuantity;
	private JButton button_2;
	private File dir = new File("src\\presentation.data");
	private Calendar ca=Calendar.getInstance();
	private int year=ca.get(Calendar.YEAR);
	private int month=ca.get(Calendar.MONTH)+1;
	private int day=ca.get(Calendar.DAY_OF_MONTH);
	private int dayHour=ca.get(Calendar.HOUR_OF_DAY);
	private int dayMin=ca.get(Calendar.MINUTE);
	private int daySec=ca.get(Calendar.SECOND);
	
	private String date=year+"."+month+"."+day;
	private String time=dayHour+" : "+dayMin+" : "+daySec;
	private JTextField tfStockPrice;
	private JLabel label_11;
	private JTable buyingDataTable;
	
	private ShoppingBasketDBA sbdba=new ShoppingBasketDBA();
	private ArrayList <ShoppingBasket> sbal;
	private JLabel lblNewLabel_9;
	
	private SalesStockDBA ssdba=new SalesStockDBA();
	
	private ArrayList <SalesStock> ssal;
	private JPanel 판매이력관리;
	private JScrollPane scrollPane_3;
	private JButton button_11;
	private JButton btnSalesViewAll;
	private JTable salesDataTable;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ManagerView frame = new ManagerView();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public ManagerView() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getTabbedPane());

		if (!dir.exists()) {
			dir.mkdir();
		}
	}

	private JTabbedPane getTabbedPane() {
		if (tabbedPane == null) {
			tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane.setToolTipText("");
			tabbedPane.setBounds(0, 0, 1008, 729);
			tabbedPane.addTab("재고관리", null, get재고관리(), null);
			tabbedPane.addTab("재고등록", null, get재고등록(), null);
			tabbedPane.addTab("구매요청관리", null, get구매요청관리(), null);
			tabbedPane.addTab("판매이력관리", null, get판매이력관리(), null);
			tabbedPane.addTab("회원정보관리", null, get회원정보관리(), null);
			tabbedPane.addTab("발주처리", null, get발주처리(), null);
		}
		return tabbedPane;
	}

	private JPanel get재고등록() {
		if (재고등록 == null) {
			재고등록 = new JPanel();
			재고등록.setLayout(null);
			재고등록.add(getLabel());
			재고등록.add(getLblNewLabel());
			재고등록.add(getLblNewLabel_1());
			재고등록.add(getLblNewLabel_2());
			재고등록.add(getLblNewLabel_3());
			재고등록.add(getLblNewLabel_5());
			재고등록.add(getLblNewLabel_7());
			재고등록.add(getLblNewLabel_8());
			재고등록.add(getTfPdtQuantity());
			재고등록.add(getTfPdtPrice());
			재고등록.add(getTfPdtName());
			재고등록.add(getCbDesktop());
			재고등록.add(getCbLaptop());
			재고등록.add(getCbPeripheralDevice());
			재고등록.add(getCbEtc());
			재고등록.add(getCbSmartPhone());
			재고등록.add(getTaPdtInfo());
			재고등록.add(getButton_5());
			재고등록.add(getTfPdtNum());
			재고등록.add(getTfEmpno());
			재고등록.add(getTfStockDate());
			재고등록.add(getTfStockPrice());
			재고등록.add(getLabel_11());
		}
		return 재고등록;
	}

	private JPanel get구매요청관리() {
		if (구매요청관리 == null) {
			구매요청관리 = new JPanel();
			구매요청관리.setLayout(null);
			구매요청관리.add(getScrollPane_2());
			구매요청관리.add(getBtnBuyViewAll());
			구매요청관리.add(getButton_8());
			구매요청관리.add(getTfBuyingNum());
			구매요청관리.add(getLblNewLabel_9());
		}
		return 구매요청관리;
	}

	private JPanel get회원정보관리() {
		if (회원정보관리 == null) {
			회원정보관리 = new JPanel();
			회원정보관리.setLayout(null);
			회원정보관리.add(getScrollPane());
			회원정보관리.add(getBtnNewButton());
			회원정보관리.add(getButton());
			회원정보관리.add(getButton_1());
			회원정보관리.add(getTfSearch());
			회원정보관리.add(getComboBox());
		}
		return 회원정보관리;
	}

	private JPanel get발주처리() {
		if (발주처리 == null) {
			발주처리 = new JPanel();
			발주처리.setLayout(null);
			발주처리.add(getLabel_1());
			발주처리.add(getTfOrder1());
			발주처리.add(getLabel_2());
			발주처리.add(getTfOrder2());
			발주처리.add(getLabel_3());
			발주처리.add(getTfOrder3());
			발주처리.add(getLabel_4());
			발주처리.add(getTfOrder4());
			발주처리.add(getLabel_5());
			발주처리.add(getTfOrder5());
			발주처리.add(getLabel_6());
			발주처리.add(getTfOrder6());
			발주처리.add(getLabel_7());
			발주처리.add(getTfOrder7());
			발주처리.add(getLabel_8());
			발주처리.add(getTfOrder8());
			발주처리.add(getLabel_9());
			발주처리.add(getTaOrder());
			발주처리.add(getTfOrderPdtNum());
			발주처리.add(getBtnNewButton_2());
			발주처리.add(getLblNewLabel_6());
			발주처리.add(getLabel_10());
			발주처리.add(getTfOrderPdtQuantity());
			발주처리.add(getButton_2());
		}
		return 발주처리;
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setBounds(0, 0, 1003, 666);
			scrollPane.setViewportView(getBuyerTable());
		}
		return scrollPane;
	}

	private JTable getBuyerTable() {
		if (buyerTable == null) {
			buyerTable = new JTable();
			buyerTable.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					int select = buyerTable.getSelectedRow();
					bal = mdba.getBuyerList();
					Buyer byr1 = new Buyer(bal.get(select).getNum(), bal.get(select).getId(),
							bal.get(select).getPassword(), bal.get(select).getName(), bal.get(select).getBirth(),
							bal.get(select).getGender(), bal.get(select).getEmail(), bal.get(select).getTel(),
							bal.get(select).getAddress(), bal.get(select).getPreference());

					BuyerDetail bdt = new BuyerDetail(byr1);
					// bdt=new BuyerDetail();
					bdt.setVisible(true);
				}
			});
			buyerTable.setModel(new DefaultTableModel());
		}
		return buyerTable;
	}

	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("전체보기");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {

					bal = mdba.getBuyerList();

					String[] cols = { "고객번호", "고객 ID", "고객 비밀번호", "이름", "생일", "성별", "이메일", "전화번호", "주소", "선호카테고리" };
					DefaultTableModel dt = new DefaultTableModel(cols, bal.size());

					buyerTable.setModel(dt);
					buyerTable.getColumnModel().getColumn(0).setPreferredWidth(62);
					buyerTable.getColumnModel().getColumn(1).setPreferredWidth(90);
					buyerTable.getColumnModel().getColumn(2).setPreferredWidth(90);
					buyerTable.getColumnModel().getColumn(3).setPreferredWidth(70);
					buyerTable.getColumnModel().getColumn(4).setPreferredWidth(80);
					buyerTable.getColumnModel().getColumn(5).setPreferredWidth(40);
					buyerTable.getColumnModel().getColumn(6).setPreferredWidth(165);
					buyerTable.getColumnModel().getColumn(7).setPreferredWidth(140);
					buyerTable.getColumnModel().getColumn(8).setPreferredWidth(248);
					buyerTable.getColumnModel().getColumn(9).setPreferredWidth(140);

					for (int i = 0; i < bal.size(); i++) {
						dt.setValueAt(bal.get(i).getNum(), i, 0);
						dt.setValueAt(bal.get(i).getId(), i, 1);
						dt.setValueAt(bal.get(i).getPassword(), i, 2);
						dt.setValueAt(bal.get(i).getName(), i, 3);
						dt.setValueAt(bal.get(i).getBirth(), i, 4);
						dt.setValueAt(bal.get(i).getGender(), i, 5);
						dt.setValueAt(bal.get(i).getEmail(), i, 6);
						dt.setValueAt(bal.get(i).getTel(), i, 7);
						dt.setValueAt(bal.get(i).getAddress(), i, 8);
						dt.setValueAt(bal.get(i).getPreference(), i, 9);
					}

				}
			});
			btnNewButton.setBounds(0, 664, 110, 36);
		}
		return btnNewButton;
	}

	private JButton getButton() {
		if (button == null) {
			button = new JButton("파일로 출력");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					File fBuyer = new File(dir, "BuyerList.txt");
					if (!fBuyer.exists()) {
						try {
							fBuyer.createNewFile();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					bal = mdba.getBuyerList();
					try {
						ps = new PrintStream(fBuyer);
						for (Buyer byr : bal) {
							ps.println("고객번호 : " + byr.getNum());
							ps.println("고객 ID : " + byr.getId());
							ps.println("고객 비밀번호 : " + byr.getPassword());
							ps.println("이름 : " + byr.getName());
							ps.println("생일 : " + byr.getBirth());
							ps.println("성별 : " + byr.getGender());
							ps.println("이메일 : " + byr.getEmail());
							ps.println("전화번호 : " + byr.getTel());
							ps.println("주소 : " + byr.getAddress());
							ps.println("선호 카테고리 : " + byr.getPreference());
							ps.println();
						}
						JOptionPane.showMessageDialog(null, "출력완료");
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} finally {
						if (ps != null)
							ps.close();
					}

				}
			});
			button.setBounds(111, 664, 110, 36);
		}
		return button;
	}

	private JButton getButton_1() {
		if (button_1 == null) {
			button_1 = new JButton("검색");
			button_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {

					String column = "";
					String value = tfSearch.getText();
					if (comboBox.getSelectedIndex() == 1) {
						column = "Buyerno";
					} else if (comboBox.getSelectedIndex() == 2) {
						column = "BuyerId";
					} else if (comboBox.getSelectedIndex() == 3) {
						column = "BuyerPwd";
					} else if (comboBox.getSelectedIndex() == 4) {
						column = "BuyerName";
					} else if (comboBox.getSelectedIndex() == 5) {
						column = "BuyerBirth";
					} else if (comboBox.getSelectedIndex() == 6) {
						column = "BuyerGender";
					} else if (comboBox.getSelectedIndex() == 7) {
						column = "BuyerEmail";
					} else if (comboBox.getSelectedIndex() == 8) {
						column = "BuyerTel";
					} else if (comboBox.getSelectedIndex() == 9) {
						column = "BuyerAddr";
					} else if (comboBox.getSelectedIndex() == 10) {
						column = "BuyerPref";
					}
					bal = mdba.buyerSearch(column, value);

					String[] cols = { "고객번호", "고객 ID", "고객 비밀번호", "이름", "생일", "성별", "이메일", "전화번호", "주소", "선호카테고리" };
					DefaultTableModel dt = new DefaultTableModel(cols, bal.size());

					buyerTable.setModel(dt);
					buyerTable.getColumnModel().getColumn(0).setPreferredWidth(62);
					buyerTable.getColumnModel().getColumn(1).setPreferredWidth(90);
					buyerTable.getColumnModel().getColumn(2).setPreferredWidth(90);
					buyerTable.getColumnModel().getColumn(3).setPreferredWidth(70);
					buyerTable.getColumnModel().getColumn(4).setPreferredWidth(80);
					buyerTable.getColumnModel().getColumn(5).setPreferredWidth(40);
					buyerTable.getColumnModel().getColumn(6).setPreferredWidth(165);
					buyerTable.getColumnModel().getColumn(7).setPreferredWidth(140);
					buyerTable.getColumnModel().getColumn(8).setPreferredWidth(248);
					buyerTable.getColumnModel().getColumn(9).setPreferredWidth(140);

					for (int i = 0; i < bal.size(); i++) {
						dt.setValueAt(bal.get(i).getNum(), i, 0);
						dt.setValueAt(bal.get(i).getId(), i, 1);
						dt.setValueAt(bal.get(i).getPassword(), i, 2);
						dt.setValueAt(bal.get(i).getName(), i, 3);
						dt.setValueAt(bal.get(i).getBirth(), i, 4);
						dt.setValueAt(bal.get(i).getGender(), i, 5);
						dt.setValueAt(bal.get(i).getEmail(), i, 6);
						dt.setValueAt(bal.get(i).getTel(), i, 7);
						dt.setValueAt(bal.get(i).getAddress(), i, 8);
						dt.setValueAt(bal.get(i).getPreference(), i, 9);
					}
				}
			});
			button_1.setBounds(893, 664, 110, 36);
		}
		return button_1;
	}

	private JTextField getTfSearch() {
		if (tfSearch == null) {
			tfSearch = new JTextField();
			tfSearch.setBounds(632, 664, 260, 36);
			tfSearch.setColumns(10);
		}
		return tfSearch;
	}

	private JComboBox getComboBox() {
		if (comboBox == null) {
			comboBox = new JComboBox();
			comboBox.setModel(new DefaultComboBoxModel(new String[] { "\uC120\uD0DD...", "\uACE0\uAC1D\uBC88\uD638",
					"\uACE0\uAC1D ID", "\uACE0\uAC1D \uBE44\uBC00\uBC88\uD638", "\uC774\uB984", "\uC0DD\uC77C",
					"\uC131\uBCC4", "\uC774\uBA54\uC77C", "\uC804\uD654\uBC88\uD638", "\uC8FC\uC18C",
					"\uC120\uD638 \uCE74\uD14C\uACE0\uB9AC" }));
			comboBox.setBounds(516, 664, 116, 36);
		}
		return comboBox;
	}
	private JPanel get재고관리() {
		if (재고관리 == null) {
			재고관리 = new JPanel();
			재고관리.setLayout(null);
			재고관리.add(getScrollPane_1());
			재고관리.add(getBtnStockViewAll());
			재고관리.add(getButton_3());
		}
		return 재고관리;
	}
	private JScrollPane getScrollPane_1() {
		if (scrollPane_1 == null) {
			scrollPane_1 = new JScrollPane();
			scrollPane_1.setBounds(0, 0, 1003, 666);
			scrollPane_1.setColumnHeaderView(getProductTable());
			scrollPane_1.setViewportView(getProductTable());
		}
		return scrollPane_1;
	}
	private JButton getBtnStockViewAll() {
		if (btnStockViewAll == null) {
			btnStockViewAll = new JButton("전체보기");
			btnStockViewAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {

					wal = whsdba.getWareHouseStockList();

					String[] cols = {"제품번호", "카테고리", "이름", "상세정보", "입고일","판매가","매출원가" ,"재고수량", "판매번호","관리자번호"};
					DefaultTableModel dt = new DefaultTableModel(cols, wal.size());

					productTable.setModel(dt);
					productTable.getColumnModel().getColumn(0).setPreferredWidth(62);
					productTable.getColumnModel().getColumn(1).setPreferredWidth(70);
					productTable.getColumnModel().getColumn(2).setPreferredWidth(90);
					productTable.getColumnModel().getColumn(3).setPreferredWidth(165);
					productTable.getColumnModel().getColumn(4).setPreferredWidth(80);
					productTable.getColumnModel().getColumn(5).setPreferredWidth(40);
					productTable.getColumnModel().getColumn(6).setPreferredWidth(70);
					productTable.getColumnModel().getColumn(7).setPreferredWidth(70);
					productTable.getColumnModel().getColumn(8).setPreferredWidth(40);
					productTable.getColumnModel().getColumn(9).setPreferredWidth(40);

					for (int i = 0; i < wal.size(); i++) {
						dt.setValueAt(wal.get(i).getProductNum(), i, 0);
						dt.setValueAt(wal.get(i).getCategory(), i, 1);
						dt.setValueAt(wal.get(i).getName(), i, 2);
						dt.setValueAt(wal.get(i).getInfo(), i, 3);
						dt.setValueAt(wal.get(i).getStockDate(), i, 4);
						dt.setValueAt(wal.get(i).getPrice(), i, 5);
						dt.setValueAt(wal.get(i).getStockPrice(), i, 6);
						dt.setValueAt(wal.get(i).getStockQuantity(), i, 7);
						dt.setValueAt(wal.get(i).getSalesNum(), i, 8);
						dt.setValueAt(wal.get(i).getEmpno(), i, 9);
					}

				}
			});
			btnStockViewAll.setBounds(0, 664, 110, 36);
		}
		return btnStockViewAll;
	}
	private JButton getButton_3() {
		if (button_3 == null) {
			button_3 = new JButton("파일로 출력");
			button_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					File fStock = new File(dir,"StockList.txt");
					if (!fStock.exists()) {
						try {
							fStock.createNewFile();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					wal = whsdba.getWareHouseStockList();
					try {
						ps = new PrintStream(fStock);
						for (WareHouseStock whs : wal) {
							ps.println("제품번호 : " + whs.getProductNum());
							ps.println("판매번호 : " + whs.getSalesNum());
							ps.println("관리자번호 : " + whs.getEmpno());
							ps.println("카테고리 : " + whs.getCategory());
							ps.println("이름 : " + whs.getName());
							ps.println("상세정보 : " + whs.getInfo());
							ps.println("재고수량 : " + whs.getStockQuantity());
							ps.println("최초입고일 : " + whs.getStockDate());
							ps.println();
						}
						JOptionPane.showMessageDialog(null, "출력완료");
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} finally {
						if (ps != null)
							ps.close();
					}

				}
			});
			button_3.setBounds(111, 664, 110, 36);
		}
		return button_3;
	}
	private JTable getProductTable() {
		if (productTable == null) {
			productTable = new JTable();
			productTable.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					int select = productTable.getSelectedRow();
					wal = whsdba.getWareHouseStockList();
					
					WareHouseStock whs=new WareHouseStock(wal.get(select).getProductNum(), wal.get(select).getStockQuantity(), wal.get(select).getPrice(), 
							wal.get(select).getSalesNum(), wal.get(select).getEmpno(), wal.get(select).getCategory(), 
							wal.get(select).getName(), wal.get(select).getInfo(), wal.get(select).getStockDate());

					WareHouseStockDetail whsdt = new WareHouseStockDetail(whs);
					
//					// bdt=new BuyerDetail();
					
					whsdt.setVisible(true);
					
				}
			});
			productTable.setModel(new DefaultTableModel());
		}
		return productTable;
	}
	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("카테고리");
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setBounds(312, 141, 57, 15);
		}
		return label;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("제품명");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(312, 222, 57, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("상세정보");
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1.setBounds(312, 292, 57, 15);
		}
		return lblNewLabel_1;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("판매가");
			lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_2.setBounds(312, 391, 57, 15);
		}
		return lblNewLabel_2;
	}
	private JLabel getLblNewLabel_3() {
		if (lblNewLabel_3 == null) {
			lblNewLabel_3 = new JLabel("입고수량");
			lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_3.setBounds(312, 419, 57, 15);
		}
		return lblNewLabel_3;
	}
	private JLabel getLblNewLabel_5() {
		if (lblNewLabel_5 == null) {
			lblNewLabel_5 = new JLabel("제품번호");
			lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_5.setBounds(315, 461, 57, 15);
		}
		return lblNewLabel_5;
	}
	private JLabel getLblNewLabel_7() {
		if (lblNewLabel_7 == null) {
			lblNewLabel_7 = new JLabel("관리자번호");
			lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_7.setBounds(303, 486, 81, 15);
		}
		return lblNewLabel_7;
	}
	private JLabel getLblNewLabel_8() {
		if (lblNewLabel_8 == null) {
			lblNewLabel_8 = new JLabel("입고일");
			lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_8.setBounds(315, 511, 57, 15);
		}
		return lblNewLabel_8;
	}
	private JTextField getTfPdtQuantity() {
		if (tfPdtQuantity == null) {
			tfPdtQuantity = new JTextField();
			tfPdtQuantity.setBounds(404, 413, 281, 21);
			tfPdtQuantity.setColumns(10);
		}
		return tfPdtQuantity;
	}
	private JTextField getTfPdtPrice() {
		if (tfPdtPrice == null) {
			tfPdtPrice = new JTextField();
			tfPdtPrice.setColumns(10);
			tfPdtPrice.setBounds(404, 388, 281, 21);
		}
		return tfPdtPrice;
	}
	private JTextField getTfPdtName() {
		if (tfPdtName == null) {
			tfPdtName = new JTextField();
			tfPdtName.setColumns(10);
			tfPdtName.setBounds(404, 219, 281, 21);
		}
		return tfPdtName;
	}
	private JCheckBox getCbDesktop() {
		if (cbDesktop == null) {
			cbDesktop = new JCheckBox("Desktop");
			cbDesktop.setBounds(404, 137, 115, 23);
		}
		return cbDesktop;
	}
	private JCheckBox getCbLaptop() {
		if (cbLaptop == null) {
			cbLaptop = new JCheckBox("Laptop");
			cbLaptop.setBounds(537, 137, 115, 23);
		}
		return cbLaptop;
	}
	private JCheckBox getCbPeripheralDevice() {
		if (cbPeripheralDevice == null) {
			cbPeripheralDevice = new JCheckBox("주변기기");
			cbPeripheralDevice.setBounds(404, 162, 115, 23);
		}
		return cbPeripheralDevice;
	}
	private JCheckBox getCbEtc() {
		if (cbEtc == null) {
			cbEtc = new JCheckBox("기타");
			cbEtc.setBounds(537, 162, 115, 23);
		}
		return cbEtc;
	}
	private JCheckBox getCbSmartPhone() {
		if (cbSmartPhone == null) {
			cbSmartPhone = new JCheckBox("스마트폰");
			cbSmartPhone.setBounds(404, 187, 115, 23);
		}
		return cbSmartPhone;
	}
	private JTextArea getTaPdtInfo() {
		if (taPdtInfo == null) {
			taPdtInfo = new JTextArea();
			taPdtInfo.setBounds(404, 250, 281, 99);
		}
		return taPdtInfo;
	}
	private JButton getButton_5() {
		if (button_5 == null) {
			button_5 = new JButton("정보확인 및 재고등록");
			button_5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {		
					//카테고리 선택, String category에 저장.
					int cbSelect=0;
					String category="";
					if(cbDesktop.isSelected()) {
						category="Desktop";
						cbSelect++;
					}
					if(cbLaptop.isSelected()) {
						category="Laptop";
						cbSelect++;
					}
					if(cbSmartPhone.isSelected()) {
						category="스마트폰";
						cbSelect++;
					}
					if(cbPeripheralDevice.isSelected()) {
						category="주변기기";
						cbSelect++;
					}
					if(cbEtc.isSelected()) {
						category="기타";
						cbSelect++;
					}
					if(cbSelect!=1 || cbSelect==0) {
						JOptionPane.showMessageDialog(null, "카테고리 선택오류");
						return;
					}
					
					String pdtName="";
					int pdtPrice=0;
					int pdtQuantity=0;
					String pdtInfo="";
					int  pdtStockPrice=0;
					
					try {
					//String pdtName,pdtInfo, int pdtPrice,pdtQuantity
					pdtName=tfPdtName.getText();
					pdtPrice=Integer.parseInt(tfPdtPrice.getText());
					pdtQuantity=Integer.parseInt(tfPdtQuantity.getText());
					pdtInfo=taPdtInfo.getText();
					pdtStockPrice=Integer.parseInt(tfStockPrice.getText());
					
					if(pdtName.isEmpty() || pdtInfo.isEmpty()) {
						JOptionPane.showMessageDialog(null, "입력정보누락");
						return;
					}
					}catch(NumberFormatException e11) {
						JOptionPane.showMessageDialog(null, "입력정보누락");
						return;
					}catch(NullPointerException e1) {
						JOptionPane.showMessageDialog(null, "입력정보누락");
						return;
					}
					
//					//WareHouseStock 객체 whs에 담기
//					WareHouseStock whs=new WareHouseStock(pdtPrice, pdtQuantity, category, pdtName, pdtInfo);
					
					//데이터베이스에 등록하기
					whsdba.insertWareHouseStock(pdtPrice, pdtQuantity, category, pdtName, pdtInfo, pdtStockPrice);
					
					//입고일, 사원번호, 제품번호 가져와서 tf들에 보내기
					String[] tmp=whsdba.getInsertedWareHouseStockValues(pdtName);
					tfPdtNum.setText(tmp[0]);
					tfStockDate.setText(tmp[1]);
					tfEmpno.setText(tmp[2]);
				}
			});
			button_5.setBounds(381, 557, 260, 42);
		}
		return button_5;
	}
	private JScrollPane getScrollPane_2() {
		if (scrollPane_2 == null) {
			scrollPane_2 = new JScrollPane();
			scrollPane_2.setBounds(0, 0, 1003, 666);
			scrollPane_2.setColumnHeaderView(getBuyingDataTable());
			scrollPane_2.setViewportView(getBuyingDataTable());
		}
		return scrollPane_2;
	}
	private JButton getBtnBuyViewAll() {
		if (btnBuyViewAll == null) {
			btnBuyViewAll = new JButton("구매요청보기");
			btnBuyViewAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					sbal=sbdba.getShoppingBasketList();
					System.out.println(sbal.size());
					String[] cols = {"구매번호", "고객번호", "제품번호", "구매수량", "재고수량","제품명","판매가"};
					DefaultTableModel dt = new DefaultTableModel(cols, sbal.size());

					buyingDataTable.setModel(dt);
					buyingDataTable.getColumnModel().getColumn(0).setPreferredWidth(62);
					buyingDataTable.getColumnModel().getColumn(1).setPreferredWidth(70);
					buyingDataTable.getColumnModel().getColumn(2).setPreferredWidth(90);
					buyingDataTable.getColumnModel().getColumn(3).setPreferredWidth(165);
					buyingDataTable.getColumnModel().getColumn(4).setPreferredWidth(80);
					buyingDataTable.getColumnModel().getColumn(5).setPreferredWidth(40);
					buyingDataTable.getColumnModel().getColumn(6).setPreferredWidth(70);
					
					for (int i = 0; i < sbal.size(); i++) {
						dt.setValueAt(sbal.get(i).getBuy_Num(), i, 0);
						dt.setValueAt(sbal.get(i).getBuyerNo(), i, 1);
						dt.setValueAt(sbal.get(i).getProduct_Num(), i, 2);
						dt.setValueAt(sbal.get(i).getBuying_Quantity(), i, 3);
						dt.setValueAt(sbal.get(i).getStock_Quantity(), i, 4);
						dt.setValueAt(sbal.get(i).getPdtName(), i, 5);
						dt.setValueAt(sbal.get(i).getSellingPrice(), i, 6);
					}
				}
			});
			btnBuyViewAll.setBounds(0, 664, 110, 36);
		}
		return btnBuyViewAll;
	}
	private JButton getButton_8() {
		if (button_8 == null) {
			button_8 = new JButton("판매확정");
			button_8.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					SalesStock ss=new SalesStock();
					ss.setBuy_Num(Integer.parseInt(tfBuyingNum.getText()));
					ShoppingBasket sb=sbdba.getShoppingBasket(ss.getBuy_Num());
					ss.setProduct_Num(sb.getProduct_Num());
					ss.setSales_Price(sb.getSellingPrice());
					ss.setSales_Quantity(sb.getBuying_Quantity());
					ssdba.confirmBuyingStuffs(ss);
					btnBuyViewAll.doClick();
					btnSalesViewAll.doClick();
					btnStockViewAll.doClick();					
				}
			});
			button_8.setBounds(893, 664, 110, 36);
		}
		return button_8;
	}
	private JTextField getTfBuyingNum() {
		if (tfBuyingNum == null) {
			tfBuyingNum = new JTextField();
			tfBuyingNum.setColumns(10);
			tfBuyingNum.setBounds(634, 664, 260, 36);
		}
		return tfBuyingNum;
	}
	private JTextField getTfPdtNum() {
		if (tfPdtNum == null) {
			tfPdtNum = new JTextField();
			tfPdtNum.setEnabled(false);
			tfPdtNum.setColumns(10);
			tfPdtNum.setBounds(404, 458, 281, 21);
		}
		return tfPdtNum;
	}
	private JTextField getTfEmpno() {
		if (tfEmpno == null) {
			tfEmpno = new JTextField();
			tfEmpno.setEnabled(false);
			tfEmpno.setColumns(10);
			tfEmpno.setBounds(404, 483, 281, 21);
		}
		return tfEmpno;
	}
	private JTextField getTfStockDate() {
		if (tfStockDate == null) {
			tfStockDate = new JTextField();
			tfStockDate.setEnabled(false);
			tfStockDate.setColumns(10);
			tfStockDate.setBounds(404, 508, 281, 21);
		}
		return tfStockDate;
	}
	
	private JLabel getLabel_1() {
		if (label_1 == null) {
			label_1 = new JLabel("제품 번호");
			label_1.setHorizontalAlignment(SwingConstants.CENTER);
			label_1.setBounds(327, 151, 85, 15);
		}
		return label_1;
	}
	private JTextField getTfOrder1() {
		if (tfOrder1 == null) {
			tfOrder1 = new JTextField();
			tfOrder1.setText("0");
			tfOrder1.setEnabled(false);
			tfOrder1.setDisabledTextColor(Color.BLACK);
			tfOrder1.setColumns(10);
			tfOrder1.setBounds(427, 148, 197, 21);
		}
		return tfOrder1;
	}
	private JLabel getLabel_2() {
		if (label_2 == null) {
			label_2 = new JLabel("판매 번호");
			label_2.setHorizontalAlignment(SwingConstants.CENTER);
			label_2.setBounds(327, 191, 85, 15);
		}
		return label_2;
	}
	private JTextField getTfOrder2() {
		if (tfOrder2 == null) {
			tfOrder2 = new JTextField();
			tfOrder2.setText("0");
			tfOrder2.setEnabled(false);
			tfOrder2.setDisabledTextColor(Color.BLACK);
			tfOrder2.setColumns(10);
			tfOrder2.setBounds(427, 188, 197, 21);
		}
		return tfOrder2;
	}
	private JLabel getLabel_3() {
		if (label_3 == null) {
			label_3 = new JLabel("관리자 번호");
			label_3.setHorizontalAlignment(SwingConstants.CENTER);
			label_3.setBounds(327, 231, 85, 15);
		}
		return label_3;
	}
	private JTextField getTfOrder3() {
		if (tfOrder3 == null) {
			tfOrder3 = new JTextField();
			tfOrder3.setText("0");
			tfOrder3.setEnabled(false);
			tfOrder3.setDisabledTextColor(Color.BLACK);
			tfOrder3.setColumns(10);
			tfOrder3.setBounds(427, 228, 197, 21);
		}
		return tfOrder3;
	}
	private JLabel getLabel_4() {
		if (label_4 == null) {
			label_4 = new JLabel("카테고리");
			label_4.setHorizontalAlignment(SwingConstants.CENTER);
			label_4.setBounds(327, 271, 85, 15);
		}
		return label_4;
	}
	private JTextField getTfOrder4() {
		if (tfOrder4 == null) {
			tfOrder4 = new JTextField();
			tfOrder4.setText("<dynamic>");
			tfOrder4.setEnabled(false);
			tfOrder4.setDisabledTextColor(Color.BLACK);
			tfOrder4.setColumns(10);
			tfOrder4.setBounds(427, 268, 197, 21);
		}
		return tfOrder4;
	}
	private JLabel getLabel_5() {
		if (label_5 == null) {
			label_5 = new JLabel("이름");
			label_5.setHorizontalAlignment(SwingConstants.CENTER);
			label_5.setBounds(327, 311, 85, 15);
		}
		return label_5;
	}
	private JTextField getTfOrder5() {
		if (tfOrder5 == null) {
			tfOrder5 = new JTextField();
			tfOrder5.setText("<dynamic>");
			tfOrder5.setEnabled(false);
			tfOrder5.setDisabledTextColor(Color.BLACK);
			tfOrder5.setColumns(10);
			tfOrder5.setBounds(427, 308, 197, 21);
		}
		return tfOrder5;
	}
	private JLabel getLabel_6() {
		if (label_6 == null) {
			label_6 = new JLabel("가격");
			label_6.setHorizontalAlignment(SwingConstants.CENTER);
			label_6.setBounds(327, 351, 85, 15);
		}
		return label_6;
	}
	private JTextField getTfOrder6() {
		if (tfOrder6 == null) {
			tfOrder6 = new JTextField();
			tfOrder6.setText("0");
			tfOrder6.setEnabled(false);
			tfOrder6.setDisabledTextColor(Color.BLACK);
			tfOrder6.setColumns(10);
			tfOrder6.setBounds(427, 348, 197, 21);
		}
		return tfOrder6;
	}
	private JLabel getLabel_7() {
		if (label_7 == null) {
			label_7 = new JLabel("입고일");
			label_7.setHorizontalAlignment(SwingConstants.CENTER);
			label_7.setBounds(327, 391, 85, 15);
		}
		return label_7;
	}
	private JTextField getTfOrder7() {
		if (tfOrder7 == null) {
			tfOrder7 = new JTextField();
			tfOrder7.setText("null");
			tfOrder7.setEnabled(false);
			tfOrder7.setDisabledTextColor(Color.BLACK);
			tfOrder7.setColumns(10);
			tfOrder7.setBounds(427, 388, 197, 21);
		}
		return tfOrder7;
	}
	private JLabel getLabel_8() {
		if (label_8 == null) {
			label_8 = new JLabel("재고수량");
			label_8.setHorizontalAlignment(SwingConstants.CENTER);
			label_8.setBounds(327, 431, 85, 15);
		}
		return label_8;
	}
	private JTextField getTfOrder8() {
		if (tfOrder8 == null) {
			tfOrder8 = new JTextField();
			tfOrder8.setText("null");
			tfOrder8.setEnabled(false);
			tfOrder8.setDisabledTextColor(Color.BLACK);
			tfOrder8.setColumns(10);
			tfOrder8.setBounds(427, 428, 197, 21);
		}
		return tfOrder8;
	}
	private JLabel getLabel_9() {
		if (label_9 == null) {
			label_9 = new JLabel("상세정보");
			label_9.setHorizontalAlignment(SwingConstants.CENTER);
			label_9.setBounds(327, 508, 85, 15);
		}
		return label_9;
	}
	private JTextArea getTaOrder() {
		if (taOrder == null) {
			taOrder = new JTextArea();
			taOrder.setText("<dynamic>");
			taOrder.setSelectionColor(Color.BLACK);
			taOrder.setLineWrap(true);
			taOrder.setEnabled(false);
			taOrder.setDisabledTextColor(Color.BLACK);
			taOrder.setBounds(424, 472, 200, 91);
		}
		return taOrder;
	}
	private JTextField getTfOrderPdtNum() {
		if (tfOrderPdtNum == null) {
			tfOrderPdtNum = new JTextField();
			tfOrderPdtNum.setBounds(358, 86, 180, 40);
			tfOrderPdtNum.setColumns(10);
		}
		return tfOrderPdtNum;
	}
	private JButton getBtnNewButton_2() {
		if (btnNewButton_2 == null) {
			btnNewButton_2 = new JButton("검색");
			btnNewButton_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int orderPdtNum=Integer.parseInt(tfOrderPdtNum.getText());
					WareHouseStock whs=whsdba.getOrderedWareHouseStock(orderPdtNum);
					tfOrder1.setText(whs.getProductNum()+"");
					tfOrder2.setText(whs.getSalesNum()+"");
					tfOrder3.setText(whs.getEmpno()+"");
					tfOrder4.setText(whs.getCategory());
					tfOrder5.setText(whs.getName());
					tfOrder6.setText(whs.getPrice()+"");
					tfOrder7.setText(whs.getStockDate()+"");
					tfOrder8.setText(whs.getStockQuantity()+"");
					taOrder.setText(whs.getInfo());
				}
			});
			btnNewButton_2.setBounds(550, 86, 85, 40);
		}
		return btnNewButton_2;
	}
	private JLabel getLblNewLabel_6() {
		if (lblNewLabel_6 == null) {
			lblNewLabel_6 = new JLabel("제품번호");
			lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_6.setBounds(289, 98, 57, 15);
		}
		return lblNewLabel_6;
	}
	private JLabel getLabel_10() {
		if (label_10 == null) {
			label_10 = new JLabel("요청수량");
			label_10.setHorizontalAlignment(SwingConstants.CENTER);
			label_10.setBounds(289, 600, 57, 15);
		}
		return label_10;
	}
	private JTextField getTfOrderPdtQuantity() {
		if (tfOrderPdtQuantity == null) {
			tfOrderPdtQuantity = new JTextField();
			tfOrderPdtQuantity.setColumns(10);
			tfOrderPdtQuantity.setBounds(358, 588, 180, 40);
		}
		return tfOrderPdtQuantity;
	}
	private JButton getButton_2() {
		if (button_2 == null) {
			button_2 = new JButton("파일 작성");
			button_2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					File fOrder = new File(dir,"LastOrder.txt");
					if (!fOrder.exists()) {
						try {
							fOrder.createNewFile();
						} catch (IOException e111) {
							e111.printStackTrace();
						}
					}
					try {
						ps = new PrintStream(fOrder);
						ps.println("제품번호 : " + tfOrder1.getText());
						ps.println("이름 : " + tfOrder5.getText());
						ps.println("재고수량 : " + tfOrder8.getText());
						ps.println("최초입고일 : " + tfOrder7.getText());
						ps.println("요청수량 : "+tfOrderPdtQuantity.getText());
						ps.println("요청일시 : "+date+"\t"+time);
						ps.println();

						JOptionPane.showMessageDialog(null, "출력완료");
					} catch (FileNotFoundException e11) {
						e11.printStackTrace();
					} finally {
						if (ps != null)
							ps.close();
					}
				}
			});
			button_2.setBounds(550, 588, 97, 40);
		}
		return button_2;
	}
	private JTextField getTfStockPrice() {
		if (tfStockPrice == null) {
			tfStockPrice = new JTextField();
			tfStockPrice.setColumns(10);
			tfStockPrice.setBounds(404, 362, 281, 21);
		}
		return tfStockPrice;
	}
	private JLabel getLabel_11() {
		if (label_11 == null) {
			label_11 = new JLabel("입고가격");
			label_11.setHorizontalAlignment(SwingConstants.CENTER);
			label_11.setBounds(312, 365, 57, 15);
		}
		return label_11;
	}
	private JTable getBuyingDataTable() {
		if (buyingDataTable == null) {
			buyingDataTable = new JTable();
		}
		return buyingDataTable;
	}
	private JLabel getLblNewLabel_9() {
		if (lblNewLabel_9 == null) {
			lblNewLabel_9 = new JLabel("구매번호");
			lblNewLabel_9.setBounds(565, 675, 57, 15);
		}
		return lblNewLabel_9;
	}
	private JPanel get판매이력관리() {
		if (판매이력관리 == null) {
			판매이력관리 = new JPanel();
			판매이력관리.setLayout(null);
			판매이력관리.add(getScrollPane_3());
			판매이력관리.add(getButton_11());
			판매이력관리.add(getBtnSalesViewAll());
		}
		return 판매이력관리;
	}
	private JScrollPane getScrollPane_3() {
		if (scrollPane_3 == null) {
			scrollPane_3 = new JScrollPane();
			scrollPane_3.setBounds(0, 0, 1003, 666);
			scrollPane_3.setColumnHeaderView(getSalesDataTable());
			scrollPane_3.setViewportView(getSalesDataTable());
		}
		return scrollPane_3;
	}
	private JButton getButton_11() {
		if (button_11 == null) {
			button_11 = new JButton("파일로 출력");
			button_11.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					File fSales = new File(dir, "SalesList.txt");
					if (!fSales.exists()) {
						try {
							fSales.createNewFile();
						} catch (IOException e11) {
							e11.printStackTrace();
						}
					}
					ssal = ssdba.getSalesStockList();
					try {
						ps = new PrintStream(fSales);
						for (SalesStock ss : ssal) {
							ps.println("판매번호 : " + ss.getSales_Num());
							ps.println("제품번호 : " + ss.getProduct_Num());
							ps.println("처리된 구매번호 : " + ss.getBuy_Num());
							ps.println("판매확정일자 : " + String.valueOf(ss.getSales_Date()));
							ps.println("판매수량 : " + ss.getSales_Quantity());
							ps.println("판매가격 : " + ss.getSales_Price());
							ps.println();
						}
						JOptionPane.showMessageDialog(null, "출력완료");
					} catch (FileNotFoundException e111) {
						e111.printStackTrace();
					} finally {
						if (ps != null)
							ps.close();
					}

				}
			});
			button_11.setBounds(109, 664, 110, 36);
		}
		return button_11;
	}
	private JButton getBtnSalesViewAll() {
		if (btnSalesViewAll == null) {
			btnSalesViewAll = new JButton("판매이력보기");
			btnSalesViewAll.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ssal=ssdba.getSalesStockList();
					
//					ss.setSales_Num(res.getInt("Sales_Num"));
//					ss.setBuy_Num(res.getInt("Buy_Num"));
//					ss.setSales_Quantity(res.getInt("Sales_Quantity"));
//					ss.setProduct_Num(res.getInt("Product_Num"));
//					ss.setSellingPrice(res.getInt("Price"));
//					ss.setPdtName(res.getString("Name"));
//					ss.setStock_Quantity(res.getInt("Stock_Quantity"));
					
					String[] cols = {"판매번호","판매확정일자", "구매요청번호", "제품번호", "판매수량", "판매가격","제품명","재고수량"};
					DefaultTableModel dt = new DefaultTableModel(cols, ssal.size());

					salesDataTable.setModel(dt);
					salesDataTable.getColumnModel().getColumn(0).setPreferredWidth(62);
					salesDataTable.getColumnModel().getColumn(1).setPreferredWidth(90);
					salesDataTable.getColumnModel().getColumn(2).setPreferredWidth(80);
					salesDataTable.getColumnModel().getColumn(3).setPreferredWidth(80);
					salesDataTable.getColumnModel().getColumn(4).setPreferredWidth(80);
					salesDataTable.getColumnModel().getColumn(5).setPreferredWidth(40);
					salesDataTable.getColumnModel().getColumn(6).setPreferredWidth(70);
					salesDataTable.getColumnModel().getColumn(7).setPreferredWidth(70);
					
					for (int i = 0; i < ssal.size(); i++) {
						dt.setValueAt(ssal.get(i).getSales_Num(), i, 0);
						dt.setValueAt(ssal.get(i).getSales_Date(), i, 1);
						dt.setValueAt(ssal.get(i).getBuy_Num(), i, 2);
						dt.setValueAt(ssal.get(i).getProduct_Num(), i, 3);
						dt.setValueAt(ssal.get(i).getSales_Quantity(), i, 4);
						dt.setValueAt(ssal.get(i).getSales_Price(), i, 5);
						dt.setValueAt(ssal.get(i).getPdtName(), i, 6);
						dt.setValueAt(ssal.get(i).getStock_Quantity(), i, 7);
					}
				}
			});
			btnSalesViewAll.setBounds(0, 664, 110, 36);
		}
		return btnSalesViewAll;
	}
	private JTable getSalesDataTable() {
		if (salesDataTable == null) {
			salesDataTable = new JTable();
		}
		return salesDataTable;
	}
}