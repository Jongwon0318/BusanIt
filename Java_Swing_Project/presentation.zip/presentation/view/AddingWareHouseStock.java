package presentation.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import presentation.model.Buyer;
import presentation.model.ManagerDBA;
import presentation.model.WareHouseStock;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Calendar;
import java.util.Scanner;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AddingWareHouseStock extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JTextField tfPdtNum;
	private JTextField tfAddDate;
	private JTextField tfAddNum;
	private JButton btnNewButton;
	private int pdtNum;
	private ManagerDBA mdba=new ManagerDBA();
	private Calendar ca=Calendar.getInstance();
	private int year=ca.get(Calendar.YEAR);
	private int month=ca.get(Calendar.MONTH)+1;
	private int day=ca.get(Calendar.DAY_OF_MONTH);
	private int dayHour=ca.get(Calendar.HOUR_OF_DAY);
	private int dayMin=ca.get(Calendar.MINUTE);
	private int daySec=ca.get(Calendar.SECOND);
	
	private String date=year+"."+month+"."+day;
	private String time=dayHour+" . "+dayMin+" . "+daySec;
	
	private PrintStream ps;
	private File dir = new File("src\\presentation.data\\AddingStockRecord");
	private File f = new File(dir, "Record("+date+","+time+").txt");
	
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					AddWareHouseStock frame = new AddWareHouseStock();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public AddingWareHouseStock(WareHouseStock whsNew) {
		pdtNum=whsNew.getProductNum();
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent arg0) {
				dispose();
			}
		});
		setBounds(100, 100, 235, 287);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblNewLabel());
		contentPane.add(getLblNewLabel_1());
		contentPane.add(getLblNewLabel_2());
		contentPane.add(getTfPdtNum());
		contentPane.add(getTfAddDate());
		contentPane.add(getTfAddNum());
		contentPane.add(getBtnNewButton());
		if (!dir.exists()) {
			dir.mkdir();
		}
	}

	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("제품번호");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setBounds(66, 28, 78, 15);
		}
		return lblNewLabel;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("입고추가일");
			lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_1.setBounds(66, 83, 78, 15);
		}
		return lblNewLabel_1;
	}
	private JLabel getLblNewLabel_2() {
		if (lblNewLabel_2 == null) {
			lblNewLabel_2 = new JLabel("추가 수량");
			lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_2.setBounds(66, 139, 78, 15);
		}
		return lblNewLabel_2;
	}
	private JTextField getTfPdtNum() {
		if (tfPdtNum == null) {
			tfPdtNum = new JTextField();
			tfPdtNum.setEnabled(false);
			tfPdtNum.setHorizontalAlignment(SwingConstants.CENTER);
			tfPdtNum.setBounds(28, 53, 161, 21);
			tfPdtNum.setColumns(10);
			tfPdtNum.setText(pdtNum+"");
		}
		return tfPdtNum;
	}
	private JTextField getTfAddDate() {
		
		if (tfAddDate == null) {
			tfAddDate = new JTextField();
			tfAddDate.setEnabled(false);
			tfAddDate.setHorizontalAlignment(SwingConstants.CENTER);
			tfAddDate.setColumns(10);
			tfAddDate.setBounds(28, 108, 161, 21);
			tfAddDate.setText(date);
		}
		return tfAddDate;
	}
	private JTextField getTfAddNum() {
		if (tfAddNum == null) {
			tfAddNum = new JTextField();
			tfAddNum.setHorizontalAlignment(SwingConstants.CENTER);
			tfAddNum.setColumns(10);
			tfAddNum.setBounds(28, 164, 161, 21);
		}
		return tfAddNum;
	}
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("추가");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					int addNum=Integer.parseInt(tfAddNum.getText());
					mdba.addingStockNum(addNum,pdtNum);
					
					JOptionPane.showMessageDialog(null, "추가완료");
					WareHouseStockDetail.btnDispose.doClick();
					ManagerView.btnStockViewAll.doClick();
					
					String addNumSave=tfAddNum.getText();
					String addAddDateSave=tfAddDate.getText();
					String addPdtNumSave=tfPdtNum.getText();
					
					ps=null;

					try {
						ps = new PrintStream(f);
						ps.println("제품번호 : "+addPdtNumSave);
						ps.println("추가수량 : "+addNumSave);
						ps.println("추가입고일 : "+addAddDateSave);
						ps.println("입력시간 : "+time);
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} finally {
						if (ps != null)
							ps.close();
					}				
					dispose();
				}
			});
			btnNewButton.setBounds(66, 198, 80, 40);
		}
		return btnNewButton;
	}
}
