package presentation.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import presentation.view.LoginView;

public class BuyerDBA {
	String url,user,password;
	
	public BuyerDBA() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			url = "jdbc:oracle:thin:@localhost:1521:xe";
			user = "hr";
			password = "1234";
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}
	
	//접속한 고객의 고객번호 가져오기
	public int getBuyerNo() {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		int buyerno=0;
		try {
			String sql="SELECT buyerno FROM Buyer WHERE BuyerId='"+LoginView.accessedId+"'";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				buyerno=res.getInt("buyerno");
			}
		} catch (SQLException e) {
			System.out.println("오류");
		} finally {
			closeConnection(con, st, res);
		}
		return buyerno;
	}
	
	//고객번호로 고객정보를 담은 객체 가져오기
	public Buyer getBuyerInfo(int buyerNo) {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		Buyer byr=null;
		try {
			byr=new Buyer();
			byr.setNum(buyerNo);
			String sql="SELECT * FROM Buyer WHERE buyerNo="+buyerNo;
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				byr.setId(res.getString("BuyerID"));
				byr.setPassword(res.getString("BuyerPwd"));
				byr.setName(res.getString("BuyerName"));
				byr.setBirth(res.getString("BuyerBirth"));
				byr.setGender(res.getString("BuyerGender"));
				byr.setEmail(res.getString("BuyerEmail"));
				byr.setTel(res.getString("BuyerTel"));
				byr.setAddress(res.getString("BuyerAddr"));
				byr.setPreference(res.getString("BuyerPref"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}

		return byr;
		
	}
	
	
	//	//아이디 중복확인 중복이면 1, 아니면 0 리턴
	public int checkId(String id) {
		int result=2;
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			String sql="SELECT * FROM buyer WHERE BuyerID = '"+id+"'";
			con=DriverManager.getConnection(url, user, password);
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(!rs.next()) {
				result=0;
			}
			else {
				result=1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConnection(con,st,rs);
		}
		return result;
	}

	//모든 조건 만족시 Buyer객체 byr을 전달받아 Database에 추가
	public void insertId(Buyer byr) {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DriverManager.getConnection(url, user, password);
			String sql = "INSERT INTO Buyer VALUES (buyer_seq.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, byr.getId());
			ps.setString(2, byr.getPassword());
			ps.setString(3, byr.getName());
			ps.setString(4, byr.getBirth());
			ps.setString(5, byr.getGender());
			ps.setString(6, byr.getEmail());
			ps.setString(7, byr.getTel());
			ps.setString(8, byr.getAddress());
			ps.setString(9, byr.getPreference());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, ps);
		}
		
	}
	
	//LoginView에서 아이디와 비밀번호 확인 후 일치하면 로그인
	public int loginConfirm(String id, String pwd) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		int result=2;
		try {
			String sql="SELECT * FROM buyer WHERE BuyerID = '"+id+"'";
			con=DriverManager.getConnection(url, user, password);
			st=con.createStatement();
			rs=st.executeQuery(sql);
			String actualPwd="";
			while(rs.next()) {
				actualPwd=rs.getString("BuyerPwd");
			}
			if(pwd.equals(actualPwd)) {
				result=0;				
			}else {
				result=1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			closeConnection(con,st,rs);
		}
		return result;
	}
	
	private void closeConnection(Connection con, Statement st, ResultSet rs) {
		try {
			if(con!=null) con.close();
			if(st!=null) st.close();
			if(rs!=null) rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}		
	}
	
	private void closeConnection(Connection con, PreparedStatement ps) {
		try {
			if(con!=null) con.close();
			if(ps!=null) ps.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}		
	}



}
