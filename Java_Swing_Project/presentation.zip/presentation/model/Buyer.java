package presentation.model;

public class Buyer {
	private int num;
	private String id,password,name,birth,gender,email,tel,address,preference;

	public Buyer() {
		
	}

	public Buyer(int num, String id, String password, String name, String birth, String gender, String email,
			String tel, String address, String preference) {
		this.num = num;
		this.id = id;
		this.password = password;
		this.name = name;
		this.birth = birth;
		this.gender = gender;
		this.email = email;
		this.tel = tel;
		this.address = address;
		this.preference = preference;
	}

	public String getTel() {
		return tel;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBirth() {
		return birth;
	}

	public String getGender() {
		return gender;
	}

	public String getEmail() {
		return email;
	}

	public String getAddress() {
		return address;
	}

	public String getPreference() {
		return preference;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setPreference(String preference) {
		this.preference = preference;
	}
	
}
