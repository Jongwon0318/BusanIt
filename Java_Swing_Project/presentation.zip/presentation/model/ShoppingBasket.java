package presentation.model;

public class ShoppingBasket {
	private int buy_Num, buyerNo, product_Num, Buying_Quantity;
//재고수량 제품명 판매가
	private int stock_Quantity;
	private String pdtName;
	private int sellingPrice;
	
	public int getStock_Quantity() {
		return stock_Quantity;
	}

	public String getPdtName() {
		return pdtName;
	}

	public int getSellingPrice() {
		return sellingPrice;
	}

	public void setStock_Quantity(int stock_Quantity) {
		this.stock_Quantity = stock_Quantity;
	}

	public void setPdtName(String pdtName) {
		this.pdtName = pdtName;
	}

	public void setSellingPrice(int sellingPrice) {
		this.sellingPrice = sellingPrice;
	}

	public ShoppingBasket() {
		super();
	}

	public int getBuy_Num() {
		return buy_Num;
	}

	public int getBuyerNo() {
		return buyerNo;
	}

	public int getProduct_Num() {
		return product_Num;
	}

	public int getBuying_Quantity() {
		return Buying_Quantity;
	}

	public void setBuy_Num(int buy_Num) {
		this.buy_Num = buy_Num;
	}

	public void setBuyerNo(int buyerNo) {
		this.buyerNo = buyerNo;
	}

	public void setProduct_Num(int product_Num) {
		this.product_Num = product_Num;
	}

	public void setBuying_Quantity(int buying_Quantity) {
		Buying_Quantity = buying_Quantity;
	}
	
}
