package presentation.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import presentation.view.LoginView;

public class WareHouseStockDBA {
	private String url, user, password;
	
	// DB세팅
	public WareHouseStockDBA() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			url = "jdbc:oracle:thin:@localhost:1521:xe";
			user = "hr";
			password = "1234";
		} catch (ClassNotFoundException e) {
			System.out.println("오류");
		}
	}
	
	//접속한 매니저 직원번호 가져오기
	public int getEmpno() {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		int empno=0;
		try {
			String sql="SELECT empno FROM Manager WHERE ManagerId='"+LoginView.accessedId+"'";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				empno=res.getInt("empno");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("오류");
		} finally {
			closeConnection(con, st, res);
		}
		return empno;
	}
	
	
	// 재고리스트인 ArrayList<WareHouseStock>을 리턴
	public ArrayList<WareHouseStock> getWareHouseStockList() {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		ArrayList<WareHouseStock> wal = null;
		WareHouseStock whs = null;
		try {
			String sql = "SELECT * FROM WareHouseStock ORDER BY Product_Num";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			wal = new ArrayList<WareHouseStock>();
			while (res.next()) {
				whs = new WareHouseStock();
				whs.setProductNum(res.getInt("Product_Num"));
				whs.setCategory(res.getString("Category"));
				whs.setName(res.getString("Name"));
				whs.setInfo(res.getString("Info"));
				whs.setStockDate(res.getDate("Stock_Date"));
				whs.setStockQuantity(res.getInt("Stock_Quantity"));
				whs.setPrice(res.getInt("Price"));
				whs.setSalesNum(res.getInt("Sales_Num"));
				whs.setEmpno(res.getInt("empno"));
				whs.setStockPrice(res.getInt("Stock_Price"));
				wal.add(whs);
			}
		} catch (SQLException e) {
			System.out.println("오류");
		} finally {
			closeConnection(con, st, res);
		}
		return wal;
	}
	
	//재고 객체 WareHouseStock을 리턴
	public WareHouseStock getOrderedWareHouseStock(int orderPdtNum) {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		WareHouseStock whs = null;
		try {
			String sql="SELECT * FROM WareHouseStock WHERE PRODUCT_NUM="+orderPdtNum;
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				whs = new WareHouseStock();
				whs.setProductNum(res.getInt("Product_Num"));
				whs.setCategory(res.getString("Category"));
				whs.setName(res.getString("Name"));
				whs.setInfo(res.getString("Info"));
				whs.setStockDate(res.getDate("Stock_Date"));
				whs.setStockQuantity(res.getInt("Stock_Quantity"));
				whs.setPrice(res.getInt("Price"));
				whs.setSalesNum(res.getInt("Sales_Num"));
				whs.setEmpno(res.getInt("empno"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return whs;
	}
	
	//재고등록
	public void insertWareHouseStock(int pdtPrice, int pdtQuantity, String category, String pdtName, String pdtInfo, int pdtStockPrice) {
		Connection con = null;
		PreparedStatement ps = null;
		try {                                                            //1,'스마트폰','갤럭시s9','최신 스마트폰', SYSDATE, 10, 1000000, 10 ,9999,1
			String sql="INSERT INTO WareHouseStock VALUES (warehousestock_seq.NEXTVAL, ?, ?, ?, SYSDATE, ?, 9999, ?, ?,?)";
			con = DriverManager.getConnection(url, user, password);
			ps=con.prepareStatement(sql);
			ps.setString(1, category);
			ps.setString(2, pdtName);
			ps.setString(3, pdtInfo);
			ps.setInt(4, pdtPrice);
			ps.setInt(5, getEmpno());
			ps.setInt(6, pdtQuantity);
			ps.setInt(7, pdtStockPrice);
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("오류");
		} finally {
			closeConnection(con, ps);
		}
	}
	
	public String[] getInsertedWareHouseStockValues(String pdtName) {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		String[] tmp=new String[3];
		try {
			String sql="SELECT * FROM WareHouseStock WHERE name='"+pdtName+"'";
			con=DriverManager.getConnection(url, user, password);
			st=con.createStatement();
			res=st.executeQuery(sql);
			while(res.next()) {
				tmp[0]=String.valueOf(res.getInt("product_num"));
				tmp[1]=String.valueOf(res.getDate("Stock_Date"));
				tmp[2]=String.valueOf(getEmpno());
			}
		} catch (SQLException e) {
			System.out.println("오류");
		}finally {
			closeConnection(con, st, res);
		}
		return tmp;
	}
		
	private void closeConnection(Connection con, PreparedStatement ps) {
		try {
			if (con != null)
				con.close();
			if (ps != null)
				ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	private void closeConnection(Connection con, Statement st, ResultSet res) {
		try {
			if (con != null)
				con.close();
			if (st != null)
				st.close();
			if (res !=null)
				res.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
