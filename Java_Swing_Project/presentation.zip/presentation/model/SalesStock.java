package presentation.model;

public class SalesStock {
	private int sales_Num, product_Num, Buy_Num, Sales_Quantity, Sales_Price;
	private String Sales_Date;
	
	//재고수량 제품명 판매가
		private int stock_Quantity;
		private String pdtName;
		
		
	public int getStock_Quantity() {
			return stock_Quantity;
		}
		public void setStock_Quantity(int stock_Quantity) {
			this.stock_Quantity = stock_Quantity;
		}
		public String getPdtName() {
			return pdtName;
		}
		public void setPdtName(String pdtName) {
			this.pdtName = pdtName;
		}

	public int getSales_Num() {
		return sales_Num;
	}
	public int getProduct_Num() {
		return product_Num;
	}
	public int getBuy_Num() {
		return Buy_Num;
	}
	public int getSales_Quantity() {
		return Sales_Quantity;
	}
	public int getSales_Price() {
		return Sales_Price;
	}
	public String getSales_Date() {
		return Sales_Date;
	}
	public void setSales_Num(int sales_Num) {
		this.sales_Num = sales_Num;
	}
	public void setProduct_Num(int product_Num) {
		this.product_Num = product_Num;
	}
	public void setBuy_Num(int buy_Num) {
		Buy_Num = buy_Num;
	}
	public void setSales_Quantity(int sales_Quantity) {
		Sales_Quantity = sales_Quantity;
	}
	public void setSales_Price(int sales_Price) {
		Sales_Price = sales_Price;
	}
	public void setSales_Date(String sales_Date) {
		Sales_Date = sales_Date;
	}
	
}
