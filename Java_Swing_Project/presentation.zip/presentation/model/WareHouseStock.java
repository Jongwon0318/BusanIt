package presentation.model;

import java.sql.Date;

public class WareHouseStock {
	private int productNum,stockQuantity, price, salesNum, empno,stockPrice;
	private String category, name, info;
	private Date stockDate;
	
	public WareHouseStock() {
		
	}

	public int getStockPrice() {
		return stockPrice;
	}

	public void setStockPrice(int stockPrice) {
		this.stockPrice = stockPrice;
	}

	public int getStockQuantity() {
		return stockQuantity;
	}

	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}

	public WareHouseStock(int productNum, int stockQuantity, int price, int salesNum, int empno,
			String category, String name, String info, Date stockDate) {
		this.productNum = productNum;
		this.stockQuantity = stockQuantity;
		this.price = price;
		this.salesNum = salesNum;
		this.empno = empno;
		this.category = category;
		this.name = name;
		this.info = info;
		this.stockDate = stockDate;
	}

	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public int getProductNum() {
		return productNum;
	}
	public Date getStockDate() {
		return stockDate;
	}

	public int getPrice() {
		return price;
	}

	public int getSalesNum() {
		return salesNum;
	}
	public String getCategory() {
		return category;
	}
	public String getName() {
		return name;
	}
	public String getInfo() {
		return info;
	}
	public void setProductNum(int productNum) {
		this.productNum = productNum;
	}
	public void setStockDate(Date date) {
		this.stockDate = date;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public void setSalesNum(int salesNum) {
		this.salesNum = salesNum;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	
}
