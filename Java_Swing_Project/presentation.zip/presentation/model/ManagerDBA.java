package presentation.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ManagerDBA {
	String url, user, password;

	// DB세팅
	public ManagerDBA() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			url = "jdbc:oracle:thin:@localhost:1521:xe";
			user = "hr";
			password = "1234";
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	// 회원리스트인 ArrayList<Buyer>를 리턴
	public ArrayList<Buyer> getBuyerList() {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		ArrayList<Buyer> bal = null;
		Buyer byr = null;
		try {
			String sql = "SELECT * FROM Buyer ORDER BY BuyerNo";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			bal = new ArrayList<Buyer>();
			while (res.next()) {
				byr = new Buyer();
				byr.setNum(res.getInt("BuyerNo"));
				byr.setId(res.getString("BuyerID"));
				byr.setPassword(res.getString("BuyerPwd"));
				byr.setName(res.getString("BuyerName"));
				byr.setBirth(res.getString("BuyerBirth"));
				byr.setGender(res.getString("BuyerGender"));
				byr.setEmail(res.getString("BuyerEmail"));
				byr.setTel(res.getString("BuyerTel"));
				byr.setAddress(res.getString("BuyerAddr"));
				byr.setPreference(res.getString("BuyerPref"));
				bal.add(byr);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return bal;

	}

	// 아이디 중복확인 중복이면 1, 아니면 0 리턴
	public int checkId(String id) {
		int result = 2;
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM manager WHERE ManagerID = '" + id + "'";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			rs = st.executeQuery(sql);
			if (!rs.next()) {
				result = 0;
			} else {
				result = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, rs);
		}
		return result;
	}

	// 사원코드 확인하여 맞으면 0, 틀리면 1 리턴
	public int checkEmpCode(String empCode) {
		int result = 0;
		if (empCode.equals("ABCDEFG")) {
			result = 0;
		} else {
			result = 1;
		}
		return result;
	}

	// 모든 조건 만족시 Manager객체 mng를 전달받음
	public void insertId(Manager mng) {
		Connection con = null;
		PreparedStatement ps = null;
		try {
			con = DriverManager.getConnection(url, user, password);
			String sql = "INSERT INTO Manager VALUES (manager_seq.NEXTVAL, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, mng.getId());
			ps.setString(2, mng.getPassword());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, ps);
		}
	}

	// LoginView에서 아이디와 비밀번호 확인 후 일치하면 로그인
	public int loginConfirm(String id, String pwd) {
		Connection con = null;
		Statement st = null;
		ResultSet rs = null;
		int result = 2;
		try {
			String sql = "SELECT * FROM manager WHERE ManagerID = '" + id + "'";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			rs = st.executeQuery(sql);
			String actualPwd = "";
			while (rs.next()) {
				actualPwd = rs.getString("ManagerPwd");
			}
			if (pwd.equals(actualPwd)) {
				result = 0;
			} else {
				result = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, rs);
		}
		return result;
	}

	public ArrayList<Buyer> buyerSearch(String column, String value) {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		ArrayList<Buyer> bal = null;
		Buyer byr;
		try {
			String sql = "SELECT * FROM Buyer WHERE " + column + " LIKE '%" + value + "%'";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			bal = new ArrayList<Buyer>();
			while (res.next()) {
				byr = new Buyer();
				byr.setNum(res.getInt("BuyerNo"));
				byr.setId(res.getString("BuyerID"));
				byr.setPassword(res.getString("BuyerPwd"));
				byr.setName(res.getString("BuyerName"));
				byr.setBirth(res.getString("BuyerBirth"));
				byr.setGender(res.getString("BuyerGender"));
				byr.setEmail(res.getString("BuyerEmail"));
				byr.setTel(res.getString("BuyerTel"));
				byr.setAddress(res.getString("BuyerAddr"));
				byr.setPreference(res.getString("BuyerPref"));
				bal.add(byr);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return bal;
	}
	
	
	//재고수량에 추가
	public void addingStockNum(int addNum,int pdtNum) {
//		UPDATE WareHouseStock 
//		SET STOCK_Quantity = (SELECT STOCK_Quantity FROM WareHouseStock WHERE Product_Num=20190003)+1 WHERE Product_Num=20190003
		Connection con=null;
		Statement st=null;
		
		try {
			String sql="UPDATE WareHouseStock "
					+"SET STOCK_Quantity = (SELECT STOCK_Quantity FROM WareHouseStock WHERE Product_Num="+pdtNum+")+"+addNum+" WHERE Product_Num="+pdtNum;
			con=DriverManager.getConnection(url, user, password);
			st=con.createStatement();
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st);
		}
	}
	
	
	private void closeConnection(Connection con, Statement st) {
		try {
			if (con != null)
				con.close();
			if (st != null)
				st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void closeConnection(Connection con, PreparedStatement ps) {
		try {
			if (con != null)
				con.close();
			if (ps != null)
				ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void closeConnection(Connection con, Statement st, ResultSet rs) {
		try {
			if (con != null)
				con.close();
			if (st != null)
				st.close();
			if (rs != null)
				rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}