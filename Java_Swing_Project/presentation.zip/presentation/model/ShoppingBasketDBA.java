package presentation.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import presentation.view.BuyerView;
import presentation.view.LoginView;

public class ShoppingBasketDBA {
	String url,user,password;
	
	public ShoppingBasketDBA() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			url = "jdbc:oracle:thin:@localhost:1521:xe";
			user = "hr";
			password = "1234";
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}
	
	//접속한 고객의 고객번호 가져오기
	public int getBuyerNo() {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		int buyerno=0;
		try {
			String sql="SELECT buyerno FROM Buyer WHERE BuyerId='"+LoginView.accessedId+"'";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				buyerno=res.getInt("buyerno");
			}
		} catch (SQLException e) {
			System.out.println("오류");
		} finally {
			closeConnection(con, st, res);
		}
		return buyerno;
	}
	
	//고객번호로 고객정보를 담은 객체 가져오기
	public Buyer getBuyerInfo(int buyerNo) {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		Buyer byr=null;
		try {
			byr=new Buyer();
			byr.setNum(buyerNo);
			String sql="SELECT * FROM Buyer WHERE buyerNo="+buyerNo;
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				byr.setId(res.getString("BuyerID"));
				byr.setPassword(res.getString("BuyerPwd"));
				byr.setName(res.getString("BuyerName"));
				byr.setBirth(res.getString("BuyerBirth"));
				byr.setGender(res.getString("BuyerGender"));
				byr.setEmail(res.getString("BuyerEmail"));
				byr.setTel(res.getString("BuyerTel"));
				byr.setAddress(res.getString("BuyerAddr"));
				byr.setPreference(res.getString("BuyerPref"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return byr;
	}
	
	public void addBuyingData(int[] productNum) {
//		INSERT INTO ShoppingBasket
//		VALUES (shoppingbasket_seq.NEXTVAL,1,20190003,10);
		Connection con = null;
		PreparedStatement ps = null;
		try {
			for(int i=0; i<productNum.length; i++) {
				con = DriverManager.getConnection(url, user, password);
				String sql="INSERT INTO ShoppingBasket VALUES (shoppingbasket_seq.NEXTVAL,"+getBuyerNo()+",?,?)";
				ps = con.prepareStatement(sql);
				ps.setInt(1, productNum[i]);
				ps.setInt(2, BuyerView.sbMap1.get(productNum[i]));
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, ps);
		}
		
	}
	
	public ShoppingBasket getShoppingBasket(int buy_num) {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		ShoppingBasket sb=null;
		try {
			String sql="SELECT * "
					+ "FROM ShoppingBasket sb "
					+ "JOIN WareHouseStock whs "
					+ "ON sb.product_num=whs.product_num "
					+ "WHERE sb.buy_Num="+buy_num;
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				sb=new ShoppingBasket();
				sb.setBuy_Num(res.getInt("Buy_Num"));
				sb.setBuyerNo(res.getInt("BuyerNo"));
				sb.setBuying_Quantity(res.getInt("Buying_Quantity"));
				sb.setProduct_Num(res.getInt("Product_Num"));
				sb.setSellingPrice(res.getInt("Price"));
				sb.setPdtName(res.getString("Name"));
				sb.setStock_Quantity(res.getInt("Stock_Quantity"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return sb;
	}
	
	public ArrayList<ShoppingBasket> getShoppingBasketList() {
//		SELECT * 
//		FROM ShoppingBasket sb
//		JOIN WareHouseStock whs
//		ON sb.product_num=whs.product_num;
		ArrayList<ShoppingBasket> sbal=new ArrayList<ShoppingBasket>();
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		ShoppingBasket sb=null;
		try {
			String sql="SELECT * "
					+ "FROM ShoppingBasket sb "
					+ "JOIN WareHouseStock whs "
					+ "ON sb.product_num=whs.product_num"
					+ " ORDER BY sb.BUY_NUM";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				sb=new ShoppingBasket();
				sb.setBuy_Num(res.getInt("Buy_Num"));
				sb.setBuyerNo(res.getInt("BuyerNo"));
				sb.setBuying_Quantity(res.getInt("Buying_Quantity"));
				sb.setProduct_Num(res.getInt("Product_Num"));
				sb.setSellingPrice(res.getInt("Price"));
				sb.setPdtName(res.getString("Name"));
				sb.setStock_Quantity(res.getInt("Stock_Quantity"));
				sbal.add(sb);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return sbal;
	}
	
	private void closeConnection(Connection con, Statement st, ResultSet rs) {
		try {
			if(con!=null) con.close();
			if(st!=null) st.close();
			if(rs!=null) rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}		
	}
	
	private void closeConnection(Connection con, PreparedStatement ps) {
		try {
			if(con!=null) con.close();
			if(ps!=null) ps.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}		
	}

}
