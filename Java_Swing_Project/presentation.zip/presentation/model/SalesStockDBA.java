package presentation.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import presentation.view.BuyerView;
import presentation.view.LoginView;

public class SalesStockDBA {
	String url,user,password;
	
	public SalesStockDBA() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			url = "jdbc:oracle:thin:@localhost:1521:xe";
			user = "hr";
			password = "1234";
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}
	
	//접속한 고객의 고객번호 가져오기
	public int getBuyerNo() {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		int buyerno=0;
		try {
			String sql="SELECT buyerno FROM Buyer WHERE BuyerId='"+LoginView.accessedId+"'";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				buyerno=res.getInt("buyerno");
			}
		} catch (SQLException e) {
			System.out.println("오류");
		} finally {
			closeConnection(con, st, res);
		}
		return buyerno;
	}
	
	//고객번호로 고객정보를 담은 객체 가져오기
	public Buyer getBuyerInfo(int buyerNo) {
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		Buyer byr=null;
		try {
			byr=new Buyer();
			byr.setNum(buyerNo);
			String sql="SELECT * FROM Buyer WHERE buyerNo="+buyerNo;
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				byr.setId(res.getString("BuyerID"));
				byr.setPassword(res.getString("BuyerPwd"));
				byr.setName(res.getString("BuyerName"));
				byr.setBirth(res.getString("BuyerBirth"));
				byr.setGender(res.getString("BuyerGender"));
				byr.setEmail(res.getString("BuyerEmail"));
				byr.setTel(res.getString("BuyerTel"));
				byr.setAddress(res.getString("BuyerAddr"));
				byr.setPreference(res.getString("BuyerPref"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return byr;
	}
	
	public void addBuyingData(int[] productNum) {
//		INSERT INTO ShoppingBasket
//		VALUES (shoppingbasket_seq.NEXTVAL,1,20190003,10);
		Connection con = null;
		PreparedStatement ps = null;
		try {
			for(int i=0; i<productNum.length; i++) {
				con = DriverManager.getConnection(url, user, password);
				String sql="INSERT INTO ShoppingBasket VALUES (shoppingbasket_seq.NEXTVAL,"+getBuyerNo()+",?,?)";
				ps = con.prepareStatement(sql);
				ps.setInt(1, productNum[i]);
				ps.setInt(2, BuyerView.sbMap1.get(productNum[i]));
				ps.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, ps);
		}
		
	}
	
	public ArrayList<SalesStock> getSalesStockList() {
//		SELECT * 
//		FROM SalesStock ss
//		JOIN WareHouseStock whs
//		ON ss.Product_num=whs.Product_num;
		ArrayList<SalesStock> ssal=new ArrayList<SalesStock>();
		Connection con = null;
		Statement st = null;
		ResultSet res = null;
		SalesStock ss=null;
		try {
			String sql="SELECT * "
					+ "FROM SalesStock ss "
					+ "JOIN WareHouseStock whs "
					+ "ON ss.Product_num=whs.Product_num "
					+ "ORDER BY ss.Sales_Num";
			con = DriverManager.getConnection(url, user, password);
			st = con.createStatement();
			res = st.executeQuery(sql);
			while(res.next()) {
				ss=new SalesStock();
				ss.setSales_Num(res.getInt("Sales_Num"));
				ss.setBuy_Num(res.getInt("Buy_Num"));
				ss.setSales_Quantity(res.getInt("Sales_Quantity"));
				ss.setProduct_Num(res.getInt("Product_Num"));
				ss.setSales_Date(res.getString("Sales_Date"));
				ss.setSales_Price(res.getInt("Price"));
				ss.setPdtName(res.getString("Name"));
				ss.setStock_Quantity(res.getInt("Stock_Quantity"));
				
				ssal.add(ss);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnection(con, st, res);
		}
		return ssal;
	}
	
	public void confirmBuyingStuffs(SalesStock ss) {
//		INSERT INTO SalesBasket
//		VALUES (sales_num, product_num, buy_num, sales_date, sales_quantity, sales_price);
		Connection con1 = null;
		PreparedStatement ps1 = null;
		Connection con2 = null;
		Statement st1 = null;
		try {
			String sql1="INSERT INTO SalesStock VALUES (salesstock_seq.NEXTVAL, ?, SYSDATE, ?, ? ,?)";
			con1 = DriverManager.getConnection(url, user, password);
			ps1=con1.prepareStatement(sql1);
			ps1.setInt(1, ss.getProduct_Num());
			ps1.setInt(2, ss.getSales_Quantity());
			ps1.setInt(3, ss.getSales_Price());
			ps1.setInt(4, ss.getBuy_Num());
			ps1.executeUpdate();
			String sql2="UPDATE WareHouseStock "
					+ "SET STOCK_Quantity = (SELECT STOCK_Quantity FROM WareHouseStock WHERE Product_Num="+ss.getProduct_Num()+")-"+ss.getSales_Quantity()
					+ " WHERE Product_Num="+ss.getProduct_Num();
			con2 = DriverManager.getConnection(url, user, password);
			st1=con2.createStatement();
			st1.executeUpdate(sql2);
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "이미 처리된 구매요청입니다.");
			return;
		} 	finally {
			closeConnection(con1, ps1);
			closeConnection(con2,st1);
			JOptionPane.showMessageDialog(null, "처리완료");
		}
		

//		try {
//			//UPDATE WareHouseStock
//			// SET STOCK_Quantity = (SELECT STOCK_Quantity FROM WareHouseStock WHERE Product_Num=20190003)-Buying_Quantity
//			// WHERE Product_Num=20190003;
//			String sql2="UPDATE WareHouseStock "
//					+ "SET STOCK_Quantity = (SELECT STOCK_Quantity FROM WareHouseStock WHERE Product_Num="+ss.getProduct_Num()+")-"+ss.getSales_Quantity()
//					+ " WHERE Product_Num="+ss.getProduct_Num();
//			con2 = DriverManager.getConnection(url, user, password);
//			st1=con2.createStatement();
//			st1.executeUpdate(sql2);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} finally {
//			closeConnection(con2,st1);
//		}
		
//		Connection con3 = null;
//		Statement st2=null;
//		try {
//			String sql3="DELETE FROM ShoppingBasket WHERE Buy_Num="+ss.getBuy_Num();
//			con3 = DriverManager.getConnection(url, user, password);
//			st2=con3.createStatement();
//			st2.executeUpdate(sql3);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} finally {
//			closeConnection(con3, st2);
//		}
//		
	}
	
	private void closeConnection(Connection con, Statement st, ResultSet rs) {
		try {
			if(con!=null) con.close();
			if(st!=null) st.close();
			if(rs!=null) rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}		
	}
	
	private void closeConnection(Connection con, PreparedStatement ps) {
		try {
			if(con!=null) con.close();
			if(ps!=null) ps.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}		
	}
	
	private void closeConnection(Connection con, Statement st) {
		try {
			if(con!=null) con.close();
			if(st!=null) st.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}		
	}



}
