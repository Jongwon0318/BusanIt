package presentation.model;

public class Manager {
	private int empno;
	private String Id,empCode;
	private String password;

	public String getEmpCode() {
		return empCode;
	}
	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}
	public int getEmpno() {
		return empno;
	}
	public String getId() {
		return Id;
	}
	public String getPassword() {
		return password;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public void setId(String id) {
		Id = id;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
