package org.photo.action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.photo.model.SPhotoBoardDAOImpl;
import org.photo.model.UsersDTO;

/**
 * Servlet implementation class FollowManager
 */
@WebServlet("/photoboard/followmanage.go")
public class FollowManager extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FollowManager() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		
		ArrayList<UsersDTO> arr=new ArrayList<UsersDTO>();
		
		String following=request.getParameter("following");
		
		String[] fol=following.split(" ");
		
		for(int i=0; i<fol.length; i++) {
			String userid=fol[i];
			UsersDTO udto=spbdao.getUser(userid);
			arr.add(udto);
		}
		
		ArrayList<UsersDTO> parr=new ArrayList<UsersDTO>();
		
		for(int i=0; i<arr.size(); i++) {
			UsersDTO pudto=spbdao.getUser(arr.get(i).getUserid());
			parr.add(pudto);
		}
		
		request.setAttribute("parr", parr);
		request.setAttribute("uarrfg", arr);
		
		RequestDispatcher rd=request.getRequestDispatcher("followingDetail.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		
		ArrayList<UsersDTO> arr=new ArrayList<UsersDTO>();
		
		String follower=request.getParameter("follower");
		
		String[] fol=follower.split(" ");
		
		for(int i=0; i<fol.length; i++) {
			String userid=fol[i];
			UsersDTO udto=spbdao.getUser(userid);
			arr.add(udto);
		}
		
		
		ArrayList<UsersDTO> parr=new ArrayList<UsersDTO>();
		
		for(int i=0; i<arr.size(); i++) {
			UsersDTO pudto=spbdao.getUser(arr.get(i).getUserid());
			parr.add(pudto);
		}
		
		request.setAttribute("parr", parr);
		request.setAttribute("uarr", arr);
		
		RequestDispatcher rd=request.getRequestDispatcher("followerDetail.jsp");
		rd.forward(request, response);
		
	}

}
