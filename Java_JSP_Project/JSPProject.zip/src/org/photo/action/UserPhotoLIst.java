package org.photo.action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.photo.model.PhotoDTO;
import org.photo.model.SPhotoBoardDAOImpl;
import org.photo.model.UsersDTO;

/**
 * Servlet implementation class UserPhotoLIst
 */
@WebServlet("/photoboard/userphotolist.go")
public class UserPhotoLIst extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserPhotoLIst() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		HttpSession session=request.getSession();
		UsersDTO priorudto=(UsersDTO)session.getAttribute("sessUdto");
		UsersDTO freshudto=spbdao.getUser(priorudto.getUserid());
		session.setAttribute("sessUdto", freshudto);
		ArrayList<PhotoDTO> arr=spbdao.userPhotoList(freshudto.getUserid());
		request.setAttribute("photoArr", arr);
		
		ArrayList<String> followerList=spbdao.getFollowerList(freshudto.getUserid());
		ArrayList<String> followingList=spbdao.getFollowingList(freshudto.getUserid());
		
		String follower="";
		for(String fwr: followerList) {
			follower+=fwr+" ";
		}
		
		String following="";
		for(String fwng: followingList) {
			following+=fwng+" ";
		}
		
		request.setAttribute("follower", follower);
		request.setAttribute("following", following);
		request.setAttribute("followerlength", followerList.size());
		request.setAttribute("followinglength", followingList.size());
		
		RequestDispatcher rd=request.getRequestDispatcher("userView.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
