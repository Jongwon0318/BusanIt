package org.photo.action;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.photo.model.SPhotoBoardDAOImpl;

/**
 * Servlet implementation class PhotoCheck
 */
@WebServlet("/photoboard/photoCheck.go")
public class PhotoCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PhotoCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String filepath=request.getParameter("filepath");
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		BufferedImage bi=spbdao.profileimageResize(filepath);
		
		//byte�� �迭�� �����Ͽ� ȭ�鿡 ���
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write( bi, "png", baos );
		baos.flush();
		byte[] imageInByteArray = baos.toByteArray();
		baos.close();
		String b64 = javax.xml.bind.DatatypeConverter.printBase64Binary(imageInByteArray);
		PrintWriter out=response.getWriter();
		out.println(b64);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String filepath=request.getParameter("filepath");
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		BufferedImage bi=spbdao.imageResize(filepath);
		
		//byte�� �迭�� �����Ͽ� ȭ�鿡 ���
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write( bi, "png", baos );
		baos.flush();
		byte[] imageInByteArray = baos.toByteArray();
		baos.close();
		String b64 = javax.xml.bind.DatatypeConverter.printBase64Binary(imageInByteArray);
		PrintWriter out=response.getWriter();
		out.println(b64);
	}

}
