package org.photo.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.photo.model.CommentsDTO;
import org.photo.model.SPhotoBoardDAOImpl;
import org.photo.model.UsersDTO;

/**
 * Servlet implementation class PhotoComment
 */
@WebServlet("/photoboard/comment.go")
public class PhotoComment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PhotoComment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		HttpSession session=request.getSession();
		UsersDTO udto=(UsersDTO)session.getAttribute("sessUdto");
		String userid=udto.getUserid();
		
		String cmsg=request.getParameter("cmsg");
		int photonum=Integer.parseInt(request.getParameter("photonum"));
		
		CommentsDTO cdto=new CommentsDTO();
		cdto.setCmsg(cmsg);
		cdto.setPhotonum(photonum);
		cdto.setUserid(userid);
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		spbdao.commentSubmit(cdto);
		
	//	request.setAttribute("cardid", photonum);
		RequestDispatcher rd=request.getRequestDispatcher("photoView.go?cardid="+photonum);
		rd.forward(request, response);
	}

}
