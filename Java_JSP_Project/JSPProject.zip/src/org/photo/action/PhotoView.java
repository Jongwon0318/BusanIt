package org.photo.action;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.photo.model.CommentsDTO;
import org.photo.model.PhotoDTO;
import org.photo.model.SPhotoBoardDAOImpl;
import org.photo.model.UsersDTO;

/**
 * Servlet implementation class PhotoView
 */
@WebServlet("/photoboard/photoView.go")
public class PhotoView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PhotoView() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		int photonum=Integer.parseInt(request.getParameter("cardid"));
				
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		
		PhotoDTO pdto=spbdao.getPhoto(photonum);
		request.setAttribute("pdto", pdto);
		
		UsersDTO udto=spbdao.getUserWithPhotonum(photonum);
		request.setAttribute("udto", udto);
		
		ArrayList<CommentsDTO> carr=spbdao.commentList(photonum);		
		request.setAttribute("carr", carr);
		
		ArrayList<UsersDTO> parr=new ArrayList<UsersDTO>();
		
		for(int i=0; i<carr.size(); i++) {
			UsersDTO pudto=spbdao.getUser(carr.get(i).getUserid());
			parr.add(pudto);
		}
		request.setAttribute("parr", parr);
		

		
		int likeCount=spbdao.getLikeCount(photonum);
		
		request.setAttribute("likeCount", likeCount);
		
		RequestDispatcher rd=request.getRequestDispatcher("photoDetail.jsp");
		rd.forward(request, response);
	}
}
