package org.photo.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.photo.model.SPhotoBoardDAOImpl;

/**
 * Servlet implementation class PhotoCollect
 */
@WebServlet("/photoboard/photocollect.go")
public class PhotoCollect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PhotoCollect() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userid=request.getParameter("userid");
		int photonum=Integer.parseInt(request.getParameter("photonum"));
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		
		//Liked ���¸� �˻�(Liked==1, �̿�==0)�Ͽ� �̹� Like ���̶�� doLike�� ��������.
		if(spbdao.checkCollected(userid, photonum)==1) {
			PrintWriter out=response.getWriter();
			out.println("<script>alert('Collected Already')");
			out.println("history.back()");
			out.println("</script>");
		}else {
			spbdao.doCollect(userid, photonum);
			RequestDispatcher rd=request.getRequestDispatcher("photoView.go?cardid="+photonum);
				rd.forward(request, response);
		}
		
	
	}

}
