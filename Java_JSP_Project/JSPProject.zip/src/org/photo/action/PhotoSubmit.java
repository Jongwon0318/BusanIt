package org.photo.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.photo.model.PhotoDTO;
import org.photo.model.SPhotoBoardDAOImpl;

/**
 * Servlet implementation class PhotoSubmit
 */
@WebServlet("/photoboard/photoSubmit.go")
public class PhotoSubmit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PhotoSubmit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String userid=request.getParameter("userid");
		String filepath=request.getParameter("filepath");
		
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		spbdao.profileimageSubmit(userid, filepath);
		
		PrintWriter out=response.getWriter();

		out.println("<script>window.opener.location.href='userphotolist.go'</script>");
		out.println("<script>self.close()</script>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		PhotoDTO pdto=new PhotoDTO();
		pdto.setContent(request.getParameter("content"));
		pdto.setFilepath(request.getParameter("filepath"));
		pdto.setReg_date(request.getParameter("reg_date"));
		pdto.setUserid(request.getParameter("userid"));
		pdto.setCategory(request.getParameter("category"));
		System.out.println(request.getParameter("category"));
		SPhotoBoardDAOImpl spbdao=SPhotoBoardDAOImpl.getInstance();
		spbdao.imageSubmit(pdto);
		PrintWriter out=response.getWriter();
		out.println("<script>window.opener.location.href='main.jsp'</script>");
		out.println("<script>self.close()</script>");
	}

}
