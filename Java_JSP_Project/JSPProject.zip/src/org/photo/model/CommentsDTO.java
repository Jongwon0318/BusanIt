package org.photo.model;

public class CommentsDTO {
	private int cnum,photonum;
	private String cmsg,userid,reg_date;
	public int getCnum() {
		return cnum;
	}
	public void setCnum(int cnum) {
		this.cnum = cnum;
	}
	public int getPhotonum() {
		return photonum;
	}
	public void setPhotonum(int photonum) {
		this.photonum = photonum;
	}
	public String getCmsg() {
		return cmsg == null ? "" : cmsg.trim();
	}
	public void setCmsg(String cmsg) {
		this.cmsg = cmsg;
	}
	public String getUserid() {
		return userid == null ? "" : userid.trim();
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getReg_date() {
		return reg_date == null ? "" : reg_date.trim();
	}
	public void setReg_date(String reg_date) {
		this.reg_date = reg_date;
	}
	
}
