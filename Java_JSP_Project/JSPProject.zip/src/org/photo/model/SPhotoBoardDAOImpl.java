package org.photo.model;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class SPhotoBoardDAOImpl implements SPhotoBoardDAO{
	
	private static SPhotoBoardDAOImpl instance=new SPhotoBoardDAOImpl();
	
	public static SPhotoBoardDAOImpl getInstance() {
		return instance;
	}
	
	private Connection getConnection() throws Exception {
		Context initCtx = new InitialContext();
		Context envCtx = (Context) initCtx.lookup("java:comp/env");
		DataSource ds = (DataSource) envCtx.lookup("jdbc/jsp");
		return ds.getConnection();
	}
	@Override
	public ArrayList<UsersDTO> userList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<PhotoDTO> photoList() {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<PhotoDTO> arr=new ArrayList<PhotoDTO>();
		try {
			con=getConnection();
			String sql="SELECT * FROM PHOTOS ORDER BY PHOTONUM DESC";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				PhotoDTO pdto=new PhotoDTO();
				pdto.setCategory(rs.getString("category"));
				pdto.setContent(rs.getString("content"));
				pdto.setFilepath(rs.getString("filepath"));
				pdto.setPhotonum(rs.getInt("photonum"));
				pdto.setReg_date(rs.getString("reg_date"));
				pdto.setUserid(rs.getString("userid"));
				arr.add(pdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return arr;
	}
	
	public ArrayList<PhotoDTO> userPhotoList(String userid) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<PhotoDTO> arr=new ArrayList<PhotoDTO>();
		try {
			con=getConnection();
			String sql="SELECT * FROM PHOTOS WHERE USERID='"+userid+"' ORDER BY PHOTONUM DESC";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				PhotoDTO pdto=new PhotoDTO();
				pdto.setCategory(rs.getString("category"));
				pdto.setContent(rs.getString("content"));
				pdto.setFilepath(rs.getString("filepath"));
				pdto.setPhotonum(rs.getInt("photonum"));
				pdto.setReg_date(rs.getString("reg_date"));
				pdto.setUserid(rs.getString("userid"));
				arr.add(pdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return arr;
	}
	
	@Override
	public ArrayList<PhotoDTO> getFollowerCollection(String userid) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<PhotoDTO> arr=new ArrayList<PhotoDTO>();
		try {
			con=getConnection();

			String sql="SELECT * FROM PHOTOS "
							+ "WHERE USERID= ANY"
							+ " (SELECT FOLLOWING"
							+ " FROM FOLLOWING"
							+ " WHERE USERID='"+userid+"')"
									+ " ORDER BY PHOTONUM DESC";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				PhotoDTO pdto=new PhotoDTO();
				pdto.setCategory(rs.getString("category"));
				pdto.setContent(rs.getString("content"));
				pdto.setFilepath(rs.getString("filepath"));
				pdto.setPhotonum(rs.getInt("photonum"));
				pdto.setReg_date(rs.getString("reg_date"));
				pdto.setUserid(rs.getString("userid"));
				arr.add(pdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return arr;
	}
	
	@Override
	public ArrayList<PhotoDTO> categoryPhotoList(String category) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<PhotoDTO> arr=new ArrayList<PhotoDTO>();
		try {
			con=getConnection();
			String sql="SELECT * FROM PHOTOS WHERE CATEGORY='"+category+"' ORDER BY PHOTONUM DESC";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				PhotoDTO pdto=new PhotoDTO();
				pdto.setCategory(rs.getString("category"));
				pdto.setContent(rs.getString("content"));
				pdto.setFilepath(rs.getString("filepath"));
				pdto.setPhotonum(rs.getInt("photonum"));
				pdto.setReg_date(rs.getString("reg_date"));
				pdto.setUserid(rs.getString("userid"));
				arr.add(pdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return arr;
	}
	
	@Override
	public ArrayList<CommentsDTO> commentList(int photonum) {
		ArrayList<CommentsDTO> carr=new ArrayList<CommentsDTO>();
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT * FROM COMMENTS WHERE PHOTONUM="+photonum+" ORDER BY CNUM DESC";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				CommentsDTO cdto=new CommentsDTO();
				cdto.setCmsg(rs.getString("cmsg"));
				cdto.setCnum(rs.getInt("cnum"));
				cdto.setPhotonum(rs.getInt("photonum"));
				cdto.setReg_date(rs.getString("reg_date"));
				cdto.setUserid(rs.getString("userid"));
				carr.add(cdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}		
		return carr;
	}

	@Override
	public UsersDTO getUser(String userid) {
		UsersDTO udto=new UsersDTO();
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT * FROM USERS WHERE USERID='"+userid+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				udto.setEmail(rs.getString("email"));
				udto.setName(rs.getString("name"));
				udto.setPi_filepath(rs.getString("pi_filepath"));
				udto.setPwd(rs.getString("pwd"));
				udto.setUserid(rs.getString("userid"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return udto;
	}
	

	
	@Override
	public UsersDTO getUserWithPhotonum(int photonum) {
		UsersDTO udto=new UsersDTO();
		
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			// SELECT * FROM USERS WHERE USERID=(SELECT USERID FROM PHOTOS WHERE PHOTONUM=8);
			String sql="SELECT * FROM USERS WHERE USERID=(SELECT USERID FROM PHOTOS WHERE PHOTONUM="+photonum+")";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				udto.setEmail(rs.getString("email"));
				udto.setName(rs.getString("name"));
				udto.setPi_filepath(rs.getString("pi_filepath"));
				udto.setPwd(rs.getString("pwd"));
				udto.setUserid(rs.getString("userid"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return udto;
	}
	
	@Override
	public PhotoDTO getPhoto(int photonum) {
		PhotoDTO pdto=new PhotoDTO();
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT * FROM PHOTOS WHERE PHOTONUM="+photonum;
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				pdto.setCategory(rs.getString("category"));
				pdto.setContent(rs.getString("content"));
				pdto.setFilepath(rs.getString("filepath"));
				pdto.setPhotonum(rs.getInt("photonum"));
				pdto.setRatio(rs.getFloat("ratio"));
				pdto.setReg_date(rs.getString("reg_date"));
				pdto.setUserid(rs.getString("userid"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return pdto;
	}

	@Override
	public int useridCheck(String userid) {
		int check=0;
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT USERID FROM USERS WHERE USERID= '"+userid+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(!rs.next()) {
				check=1;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}		
		return check;
	}
	
	@Override
	public int userInsert(UsersDTO udto) {
		int check=0;
		Connection con=null;
		PreparedStatement ps=null;
		try {
			con=getConnection();
			String sql="INSERT INTO USERS (USERID,PWD,NAME,EMAIL) VALUES (?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, udto.getUserid());
			ps.setString(2, udto.getPwd());
			ps.setString(3, udto.getName());
			ps.setString(4, udto.getEmail());
			ps.execute();
		}catch(Exception e) {
			check=1;
		}finally {
			closeConnection(con, ps);
		}
		return check;
	}
	
	@Override
	public int userLogin(String loginId, String loginPwd) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		int check=-1;
		try {
			con=getConnection();
			String sql="SELECT PWD FROM USERS WHERE USERID='"+loginId+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				if(rs.getString("Pwd").equals(loginPwd)) {
					check=2;
				}else {
					check=1;
				}
			}else {
				check=0;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return check;
	}
	
	@Override
	public void imageSubmit(PhotoDTO pdto) {
		Connection con=null;
		PreparedStatement ps=null;
		try {
			con=getConnection();
			String sql="INSERT INTO PHOTOS(PHOTONUM,CATEGORY,CONTENT,FILEPATH,REG_DATE,USERID,RATIO) VALUES(PHOTOS_SEQ.NEXTVAL,?,?,?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, pdto.getCategory());
			ps.setString(2, pdto.getContent());
			ps.setString(3, pdto.getFilepath());
			ps.setString(4, pdto.getReg_date());
			ps.setString(5, pdto.getUserid());
			ps.setFloat(6, photoRatio(pdto.getFilepath()));
			ps.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, ps);
		}
	}
	
	private float photoRatio(String filepath) {
		float scale=0;
		try {
		URL url=new URL(filepath);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.addRequestProperty("User-Agent", "Mozilla");
		BufferedImage img=ImageIO.read(connection.getInputStream());
		float width=img.getWidth();
		float height=img.getHeight();
		scale=(width/height);
		}catch (IOException e) {
			e.printStackTrace();
		}
		return scale;
	}
	
	@Override
	public void commentSubmit(CommentsDTO cdto) {
		Connection con=null;
		PreparedStatement ps=null;
		try {
			con=getConnection();
			String sql="INSERT INTO COMMENTS VALUES(COMMENTS_SEQ.NEXTVAL,?,?,?,SYSDATE)";
			ps=con.prepareStatement(sql);
			ps.setInt(1, cdto.getPhotonum());
			ps.setString(2, cdto.getCmsg());
			ps.setString(3, cdto.getUserid());
			ps.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, ps);
		}
	}
	
	@Override
	public void addFollow(String userid, String otheruserid) {
		Connection con=null;
		Statement st=null;
		try {			
			con=getConnection();
			//INSERT INTO FOLLOWING(USERID,FOLLOWING) VALUES (userid,otheruserid);
			//INSERT INTO FOLLOWER(USERID,FOLLOWER) VALUES (otheruserid,userid);
			String sql="INSERT INTO FOLLOWING(USERID,FOLLOWING) VALUES('"+userid+"', '"+otheruserid+"')";
			st=con.createStatement();
			st.execute(sql);
			con.commit();
			String sql2="INSERT INTO FOLLOWER(USERID,FOLLOWER) VALUES('"+otheruserid+"', '"+userid+"')";
			st.execute(sql2);
			con.commit();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con,st);
		}
	}
	
	
	@Override
	public void doDownload(int photonum) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		String filepath="";
		try {
			con=getConnection();
			String sql="SELECT FILEPATH FROM PHOTOS WHERE PHOTONUM="+photonum;
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				filepath=rs.getString("FILEPATH");
			}
			URL url=new URL(filepath);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.addRequestProperty("User-Agent", "Mozilla");
			BufferedImage img=ImageIO.read(connection.getInputStream());
			File dir=new File("C:\\Users\\it\\Desktop\\Java Study.Swing\\SecondJava\\JSPwork\\SecondProject\\WebContent\\photoboard\\images");
			File outputfile = new File(dir,photonum+".png");
			
			ImageIO.write(img, "png", outputfile);
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		
	}
	
	@Override
	public BufferedImage imageResize(String filepath) {
		//filepath ="http���"
		BufferedImage resizedImage=null;
		try {
			URL url=new URL(filepath);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.addRequestProperty("User-Agent", "Mozilla");
			BufferedImage img=ImageIO.read(connection.getInputStream());
			
			float width=img.getWidth();
			float height=img.getHeight();
			float scale=(width/height); // ����/���� ����
			int resizeWidth=0;
			int resizeHeight=0;
			if(scale>1) { //������ ����
				resizeWidth=924;
				resizeHeight=Math.round(924/scale);
				if(resizeHeight>400) {
					resizeHeight=400;
					resizeWidth=Math.round(400*scale);
				}
			}else if(0<scale && scale<1){ //������ ����
				resizeHeight=400;
				resizeWidth=Math.round(400*scale);
			}else if(scale==1) {
				resizeWidth=400;
				resizeHeight=400;
			}
			
			//ȭ�� ����� ���� resizing
			resizedImage=resize(img, resizeHeight, resizeWidth);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return resizedImage;
	}
	
	public BufferedImage profileimageResize(String filepath) {
		//filepath ="http���"
		BufferedImage resizedImage=null;
		try {
			URL url=new URL(filepath);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.addRequestProperty("User-Agent", "Mozilla");
			BufferedImage img=ImageIO.read(connection.getInputStream());
			
			float width=img.getWidth();
			float height=img.getHeight();
			float scale=(width/height); // ����/���� ����
			int resizeWidth=0;
			int resizeHeight=0;
			if(scale>1) { //������ ����
				resizeWidth=300;
				resizeHeight=Math.round(300/scale);
				if(resizeHeight>300) {
					resizeHeight=300;
					resizeWidth=Math.round(300*scale);
				}
			}else if(0<scale && scale<1){ //������ ����
				resizeHeight=300;
				resizeWidth=Math.round(300*scale);
			}else if(scale==1) {
				resizeWidth=300;
				resizeHeight=300;
			}
			
			//ȭ�� ����� ���� resizing
			resizedImage=resize(img, resizeHeight, resizeWidth);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return resizedImage;
	}
	
	private BufferedImage resize(BufferedImage img, int resizeHeight, int resizeWidth) {
        Image tmp = img.getScaledInstance(resizeWidth, resizeHeight, Image.SCALE_SMOOTH);
        BufferedImage resized = new BufferedImage(resizeWidth, resizeHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = resized.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();
        return resized;
    }
	
	@Override
	public void profileimageSubmit(String userid, String filepath) {
		Connection con=null;
		Statement st=null;
		try {
			con=getConnection();
			String sql="UPDATE USERS "
							+ "SET PI_FILEPATH='"+filepath+"' "
							+ "WHERE USERID='"+userid+"'";
			st=con.createStatement();
			st.execute(sql);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st);
		}
	}
	
	@Override
	public void doLike(String userid, int photonum) {
		Connection con=null;
		PreparedStatement ps=null;
		
		try {
			con=getConnection();
			String sql="INSERT INTO PHOTOLIKE(PHOTONUM,USERID) VALUES(?,?)";
			ps=con.prepareStatement(sql);
			ps.setInt(1, photonum);
			ps.setString(2, userid);
			ps.execute();
			con.commit();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, ps);
		}
	}
	
	@Override
	public void doCollect(String userid, int photonum) {
		Connection con=null;
		PreparedStatement ps=null;
		
		try {
			con=getConnection();
			String sql="INSERT INTO COLLECTIONS(	USERID,PHOTONUM) VALUES(?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, userid);
			ps.setInt(2, photonum);
			ps.execute();
			con.commit();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, ps);
		}
	}
	
	@Override
	public ArrayList<String> getFollowerList(String userid) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<String> arr=new ArrayList<String>();
		try {
			con=getConnection();
			String sql="SELECT FOLLOWER FROM FOLLOWER WHERE USERID='"+userid+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				arr.add(rs.getString("FOLLOWER"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st,rs);
		}
		return arr;
	}

	@Override
	public ArrayList<String> getFollowingList(String userid) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<String> arr=new ArrayList<String>();
		try {
			con=getConnection();
			String sql="SELECT FOLLOWING FROM FOLLOWING WHERE USERID='"+userid+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				arr.add(rs.getString("FOLLOWING"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st,rs);
		}
		return arr;
	}
	
	@Override
	public int checkFollow(String userid, String otheruserid) {
		int check=0;
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT FOLLOWER FROM FOLLOWER WHERE USERID='"+otheruserid+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				if(rs.getString("FOLLOWER").equals(userid)) {
					check=1;
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return check;
	}

	@Override
	public int checkLiked(String userid, int photonum) {
		int check=0;
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT PHOTONUM FROM PHOTOLIKE WHERE USERID='"+userid+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				if(rs.getInt("PHOTONUM")==photonum) {
					check=1;
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return check;
	}
	
	@Override
	public int checkCollected(String userid, int photonum) {
		int check=0;
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT PHOTONUM FROM COLLECTIONS WHERE USERID='"+userid+"'";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				if(rs.getInt("PHOTONUM")==photonum) {
					check=1;
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return check;
	}
	
	@Override
	public int getLikeCount(int photonum) {
		int check=0;
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		try {
			con=getConnection();
			String sql="SELECT COUNT(*) FROM PHOTOLIKE WHERE PHOTONUM="+photonum;
			st=con.createStatement();
			rs=st.executeQuery(sql);
			if(rs.next()) {
				check=rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st);
		}
		return check;
	}
	
	@Override
	public ArrayList<PhotoDTO> getCollection(String userid) {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		ArrayList<PhotoDTO> arr=new ArrayList<PhotoDTO>();
		try {
			con=getConnection();
			String sql="SELECT * FROM PHOTOS "
							 + "WHERE PHOTONUM= ANY"
							 + " (SELECT PHOTONUM "
							 + "FROM COLLECTIONS "
							 + "WHERE USERID='"+userid+"') "
							 + "ORDER BY PHOTONUM DESC";
			st=con.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()) {
				PhotoDTO pdto=new PhotoDTO();
				pdto.setCategory(rs.getString("category"));
				pdto.setContent(rs.getString("content"));
				pdto.setFilepath(rs.getString("filepath"));
				pdto.setPhotonum(rs.getInt("photonum"));
				pdto.setReg_date(rs.getString("reg_date"));
				pdto.setUserid(rs.getString("userid"));
				arr.add(pdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			closeConnection(con, st, rs);
		}
		return arr;
	}
		
	private void closeConnection(Connection con, Statement st) {
		try {
		if(con!=null) con.close();
		if(st!=null) st.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void closeConnection(Connection con, PreparedStatement ps) {
		try {
		if(con!=null) con.close();
		if(ps!=null) ps.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	private void closeConnection(Connection con, Statement st, ResultSet rs) {
		try {
		if(con!=null) con.close();
		if(st!=null) st.close();
		if(rs!=null) rs.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
