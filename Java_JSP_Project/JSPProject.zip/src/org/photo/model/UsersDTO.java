package org.photo.model;

public class UsersDTO {
	
	private String userid,pwd,name,pi_filepath,email;
	
	public String getEmail() {
		return email == null ? "" : email.trim();
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserid() {
		return userid == null ? "" : userid.trim();
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPwd() {
		return pwd == null ? "" : pwd.trim();
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name == null ? "" : name.trim();
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPi_filepath() {
		return pi_filepath == null ? "" : pi_filepath.trim();
	}
	public void setPi_filepath(String pi_filepath) {
		this.pi_filepath = pi_filepath;
	}
	
}
